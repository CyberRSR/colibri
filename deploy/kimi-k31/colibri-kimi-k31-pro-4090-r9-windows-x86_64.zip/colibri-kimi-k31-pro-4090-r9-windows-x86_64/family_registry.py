#!/usr/bin/env python3
"""Authoritative model-family registry for Colibri's Python control plane."""

import os
from dataclasses import dataclass
import json
import math
import re
from pathlib import Path


class RegistryError(ValueError):
    pass


class FamilyConfigError(ValueError):
    pass


class UnknownFamilyError(ValueError):
    pass


class PlannerUnsupportedError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class FamilyCapabilities:
    tools: bool
    grammar_payload: bool
    audio_payload: bool
    thinking: bool
    # The gateway has a placeholder expansion for this family's pictures. Whether
    # the checkpoint being served loaded its tower is the engine's word (the CAPS
    # handshake line, openai_server.Engine.vision), never this bit's: a glm53
    # export can carry vision_config and no model.visual.* tensors.
    image: bool = False
    # A decision engine: it answers POST /v1/systemone natively (the DECIDE
    # command) and generates nothing. The engine confirms it at start-up with
    # `CAPS decide=1 chat=0`, which is what the gateway routes on.
    decision: bool = False
    # The numeric logprobs/echo channel (the SUBMIT `logprobs=` key): the engine
    # emits one ECHO frame per prompt position it read out, position 0 included
    # (" nan 0"), so the gateway can serve a run that starts at 0 -- which is what
    # /v1/completions with `echo: true` promises and what a scoring harness reads.
    # colibri.c, mimo.c and qwen36.c keep that contract. An engine that resumes a
    # read-out from a live prefix without a pin photo answers it with a hole, and
    # the gateway refuses that by name rather than shifting every logprob by one
    # token (engine_pinned_prefix_not_echoed).
    logprobs_echo: bool = False
    # The family's SUBMIT header carries the seventh (gbytes) numeric field in front
    # of the key=value extension keys -- the shape decode_batch.h's coli_submit_parse
    # reads. The siblings speak a 6-field header (c/qwen36.c takes its keys straight
    # after top_p), so handing them the extra field puts a bare `0` where their
    # parser wants `key=value` and the engine answers "bad submit extension".
    submit_gbytes: bool = False


@dataclass(frozen=True, slots=True)
class FamilyLimits:
    default_context: int
    max_context: int
    default_max_output: int
    interactive_max_output: int
    max_kv_slots: int
    implicit_cap: int
    context_env: str


@dataclass(frozen=True, slots=True)
class DisplayVariant:
    """One checkpoint geometry a family serves, and what to call it.

    A family is keyed by model_type, and one model_type can cover checkpoints
    of very different size: Qwen3.6-35B-A3B and Qwen3.8-2.4T-A95B both say
    ``qwen3_5_moe_text``. A single display_name would announce the 2.4T as a
    35B, which is the kind of banner that costs someone a day (#1045). The
    ``geometry`` pairs are config keys the family config must match exactly
    (positive integers, or the model_type itself as a string, where one family
    serves two models: GLM-5.2's engine runs Mistral-Large-4 too); the first
    matching variant names the model. No match: the model keeps its own
    model_type as its name rather than borrowing a sibling's.
    """
    geometry: tuple
    display_name: str
    display_scale: str
    # The API model id for this checkpoint, when it must not borrow the family's:
    # set only where no id was ever announced for it, so existing clients of the
    # 35B and 2.4T keep the id they were configured with.
    model_id: str = ""


@dataclass(frozen=True, slots=True)
class PlannerGeometry:
    context_state_bytes: int
    fixed_state_bytes: int
    workspace_bytes: int
    configured_experts: int
    # A dense checkpoint (no expert count in its config): zero experts is its shape,
    # not a broken MoE config, and the planner keeps every weight resident (#1757).
    dense: bool = False


@dataclass(frozen=True, slots=True)
class FamilyDescriptor:
    id: str
    model_types: tuple
    display_name: str
    display_scale: str
    engine_artifact: str
    engine_aliases: tuple
    engine_group: str
    internal_arch: str
    build_target: str
    process_names: tuple
    default_model_id: str
    cli_adapter: str
    gateway_adapter: str
    planner_id: str
    planner_geometry: object
    planner_unsupported_reason: str
    expert_inventory: object
    config_section: str
    limits: FamilyLimits
    capabilities: FamilyCapabilities
    resident_inventory: object = None
    # Quanto pesano in RAM i pesi densi rispetto a come stanno su disco.
    # Vale 1.0 per chi li carica cosi' come sono; un motore che li riquantizza
    # a load time pesa meno, e senza questo il pianificatore direbbe che il
    # modello non ci sta quando invece ci sta.
    dense_load_ratio: object = None      # callable(bytes_su_disco) -> bytes in RAM
    has_gateway_adapter: bool = False
    has_cli_adapter: bool = False
    tune_prompt_template: str = "{prompt}"
    # The environment variable the engine reads for extra shard folders, a model
    # split across drives (st_init_multi: the shards of every listed folder, by
    # file name). The launcher looks there too before it calls a model incomplete
    # or downloads a shard again (#2091). Empty: the engine reads one folder.
    split_dirs_env: str = ""
    supports_accelerator: bool = True
    # Size-keyed names for families whose model_type spans several checkpoint
    # sizes. Empty: display_name/display_scale name every checkpoint.
    display_variants: tuple = ()
    # Optional model-owned allocations that are neither dense resident
    # tensors nor per-expert cache entries. Qwen3.8 uses this for the
    # normalized FP8 scale bank shared by every cache slot. Keeping this
    # separate from expert_inventory prevents a fixed allocation from
    # being multiplied by the cache capacity.
    fixed_resident_inventory: object = None
    # Bytes of a dense tensor that the engine's GPU trunk offload would hold
    # in VRAM (int8 per row, quantized at load time), so the planner can take
    # the trunk out of the VRAM budget before it counts hot experts. None: the
    # engine keeps its trunk on the CPU (or has none).
    trunk_inventory: object = None
    # Lo script sotto tools/ che `coli convert` puo' guidare per questa famiglia,
    # e le opzioni di `coli convert` che quello script accetta davvero.
    #
    # #1368: `coli convert` lanciava convert_fp8_to_int4.py qualunque cosa gli si
    # desse. Quel convertitore e' di GLM-5.2 e classifica i tensori per nome
    # PIATTO, mentre GLM-5.3-Flash annida il testuale sotto il wrapper vision:
    # `model.language_model.embed_tokens.weight` non corrisponde a nessuna regola
    # e cade nel fallback finale, che lo quantizza. Poi glm53.c lo legge con
    # load_f32, rifiuta l'U8, e il motore muore dentro `coli web`.
    #
    # Vuoto significa "coli non guida questa famiglia": non e' una lacuna, e'
    # che il suo convertitore ha un'altra riga di comando (convert_qwen36.py usa
    # --out e --gs, convert_inkling_int4.py non ha --repo) o non serve affatto
    # (Qwen3.8 gira sul checkpoint ufficiale). In quel caso si lascia parlare la
    # guardia del convertitore, che quelle indicazioni le ha gia' per famiglia e
    # sotto test: due copie della stessa mappa sarebbero il difetto che questa
    # correzione sta chiudendo.
    converter: str = ""
    converter_accepts: tuple = ()
    converter_mtp_pass: bool = False
    # Gli esperti per layer del checkpoint con cui display_scale e' stato
    # scritto. display_scale e' un numero del checkpoint di riferimento, non
    # della famiglia: un checkpoint potato (REAP) ha la stessa architettura e
    # lo stesso model_type ma meno esperti, e annunciarlo con la taglia del
    # riferimento e' lo stesso errore di #1367 -- con la differenza che qui
    # la geometria lo rende visibile. 0 = nessun riferimento dichiarato, il
    # banner stampa display_scale come sempre.
    reference_experts: int = 0
    # "text" for the chat engines, "image" for a text-to-image pipeline,
    # "decision" for a decision model. An image family has no KV cache, no
    # experts and no chat template: coli routes it to the image REPL, the image
    # planner and POST /v1/images/generations, and every text-only invariant
    # (context variable, segment conformance, tuning) is scoped to modality
    # "text". A decision family has none of them either: it is served by
    # `coli serve` / `coli web` and answers POST /v1/systemone only.
    modality: str = "text"
    # Where the tokenizer lives, relative to the model directory. A diffusers
    # pipeline keeps it in processor/, not at the root.
    tokenizer_file: str = "tokenizer.json"
    # The other files a decision checkpoint needs besides model.safetensors and
    # the tokenizer, relative to the model directory: what `coli doctor`
    # checks. Each decision family keeps its configuration in its own layout.
    checkpoint_files: tuple = ()


@dataclass(frozen=True, slots=True)
class ResolvedFamily:
    descriptor: FamilyDescriptor
    model_type: str
    config: dict
    family_config: dict
    model_dir: str
    # A decision head over a text family's backbone (Cloudflare's Clef: a qwen36
    # container with joint_head_config.json and joint_head.safetensors). The
    # engine then answers POST /v1/systemone natively AND chats; the family, its
    # planner and its limits stay the backbone's. "" for every other checkpoint.
    decision_head: str = ""


@dataclass(frozen=True, slots=True)
class DecisionHead:
    """A decision head a text engine loads beside its backbone (docs/clef.md)."""
    id: str
    family: str                  # the engine that runs the backbone and the head
    files: tuple                 # all of them next to the shards
    display_name: str
    model_id: str
    # (geometry, display_scale): the backbone sizes the head ships on
    scales: tuple = ()
    # The context a checkpoint with this head gets when nothing asks for another:
    # the head's own input budget (Clef's encode_record max_length). 0 = the family's.
    default_context: int = 0
    # COLI_DENSE_BITS the gateway sets when the planner's RAM budget holds the
    # trunk at that width (docs/clef.md: int8 moves Clef's probabilities by up to
    # 0.22, f16 by 0.012). 0 = the engine's own default.
    precise_dense_bits: int = 0


DECISION_HEADS = (
    DecisionHead("clef", "qwen36", ("joint_head_config.json", "joint_head.safetensors"),
                 "Clef", "clef",
                 scales=(((("num_hidden_layers", 64), ("hidden_size", 5120),
                           ("intermediate_size", 17408)), "27B"),),
                 default_context=16384, precise_dense_bits=16),
)


def decision_head_of(resolved):
    """The DecisionHead a resolved checkpoint carries, or None."""
    for head in DECISION_HEADS:
        if head.id == resolved.decision_head:
            return head
    return None


def default_context(resolved):
    """The context a resolved checkpoint runs at when none is asked for: its
    decision head's own budget (Clef: 16384), else the family's default."""
    head = decision_head_of(resolved)
    if head and head.default_context:
        return head.default_context
    return resolved.descriptor.limits.default_context


def checkpoint_decides(resolved):
    """True when the checkpoint answers POST /v1/systemone natively: a decision
    family (Laya), or a text family with a decision head (Clef)."""
    return resolved.descriptor.modality == "decision" or bool(resolved.decision_head)


def _required_int(config, key, family, minimum=1):
    value = config.get(key)
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{family}: missing or invalid planning key {key!r}")
    return value


def _optional_int(config, key, default=0, minimum=0):
    value = config.get(key, default)
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"invalid planning key {key!r}")
    return value


def _glm_geometry(config, context, _model_dir):
    layers = _required_int(config, "num_hidden_layers", "glm") + 1
    experts = _required_int(config, "n_routed_experts", "glm")
    kv_lora = _required_int(config, "kv_lora_rank", "glm")
    rope = _required_int(config, "qk_rope_head_dim", "glm")
    heads = _required_int(config, "num_attention_heads", "glm")
    nope = _required_int(config, "qk_nope_head_dim", "glm")
    value = _required_int(config, "v_head_dim", "glm")
    state = layers * context * (kv_lora + rope) * 4
    index_dim = _optional_int(config, "index_head_dim", 0)
    if index_dim and config.get("_colibri_indexer_present", False):
        kinds = config.get("indexer_types")
        if isinstance(kinds, list):
            active = sum(kind == "full" for kind in kinds[:layers - 1])
        else:
            frequency = max(1, _optional_int(config, "index_topk_freq", 1, 1))
            offset = _optional_int(config, "index_skip_topk_offset", 2)
            active = 0
            for layer in range(layers - 1):
                index_value = max(layer - offset + 1, 0)
                active += index_value % frequency == 0
        state += active * context * index_dim * 4
    workspace = context * heads * (nope + value) * 4
    return PlannerGeometry(state, 0, workspace, experts)


def _qwen36_layer_types(config, layers, model_dir):
    """The per-layer kinds, from wherever this container wrote them. The HF
    config carries `layer_types`; older converted containers carry them only in
    qwen36_meta.json (the engine reads that file, which is why chat worked
    while doctor and plan refused, #1532); and the upstream class derives them
    from `full_attention_interval` when neither list is present."""
    kinds = config.get("layer_types")
    if isinstance(kinds, list) and len(kinds) == layers:
        return kinds
    if model_dir:
        try:
            with open(os.path.join(model_dir, "qwen36_meta.json"), encoding="utf-8") as handle:
                meta = json.load(handle)
        except (OSError, ValueError):
            meta = None
        if isinstance(meta, dict):
            kinds = meta.get("layer_types")
            if isinstance(kinds, list) and len(kinds) == layers:
                return kinds
    if config.get("model_type") in ("qwen3_moe", "qwen3"):
        # Qwen3 MoE (Qwen3-Coder-30B-A3B) and the dense Qwen3: every layer is attention, no DeltaNet.
        return ["full_attention"] * layers
    interval = config.get("full_attention_interval")
    if isinstance(interval, int) and not isinstance(interval, bool) and interval >= 1:
        return ["full_attention" if (i + 1) % interval == 0 else "linear_attention"
                for i in range(layers)]
    raise ValueError("qwen36: missing or invalid planning key 'layer_types' "
                     "(not in config.json, no qwen36_meta.json with it, and no "
                     "full_attention_interval to derive it from)")


def _qwen36_geometry(config, context, _model_dir):
    """Hybrid: only the full_attention layers hold a KV cache; the linear
    (DeltaNet) layers carry a recurrent state whose size does not depend on the
    context at all. One scaled context term would over-promise on a model where
    30 of 40 layers never grow."""
    layers = _required_int(config, "num_hidden_layers", "qwen36")
    kinds = _qwen36_layer_types(config, layers, _model_dir)
    # Flint's and Muse Spark's sliding_attention layers keep their rows like the full ones (the
    # engine's KV is one array per attention layer, the window applied when it reads)
    full = sum(kind in ("full_attention", "sliding_attention") for kind in kinds)
    kv = (full * context * _required_int(config, "num_key_value_heads", "qwen36") *
          _required_int(config, "head_dim", "qwen36") * 2 * 4)
    if any(kind == "conv" for kind in kinds):
        # LFM3: a conv layer keeps its last conv_L_cache - 1 rows of every channel, whatever
        # the context; the MLP is dense, nothing routed
        taps = _required_int(config, "conv_L_cache", "qwen36", 2)
        conv = sum(kind == "conv" for kind in kinds)
        fixed = conv * _required_int(config, "hidden_size", "qwen36") * (taps - 1) * 4
        return PlannerGeometry(kv, fixed, 0, 0, dense=True)
    if full == layers:
        # all attention (qwen3_moe): no recurrent state, and no linear_* keys to read
        if "num_experts" not in config:
            return PlannerGeometry(kv, 0, 0, 0, dense=True)
        return PlannerGeometry(kv, 0, 0, _required_int(config, "num_experts", "qwen36"))
    key_heads = _required_int(config, "linear_num_key_heads", "qwen36")
    key_dim = _required_int(config, "linear_key_head_dim", "qwen36")
    value_heads = _required_int(config, "linear_num_value_heads", "qwen36")
    value_dim = _required_int(config, "linear_value_head_dim", "qwen36")
    conv_k = _required_int(config, "linear_conv_kernel_dim", "qwen36", 2)
    conv_dim = key_heads * key_dim * 2 + value_heads * value_dim
    fixed = (layers - full) * (value_heads * key_dim * value_dim +
                               conv_dim * (conv_k - 1)) * 4
    # A dense checkpoint of the family (Qwen3.8-27B, #1757) has no num_experts: nothing
    # to cache, every weight resident.
    if "num_experts" not in config:
        return PlannerGeometry(kv, fixed, 0, 0, dense=True)
    return PlannerGeometry(kv, fixed, 0, _required_int(config, "num_experts", "qwen36"))


_QWEN38_PREFILL_BATCH_ROWS = 32
_QWEN38_PREFILL_WORKSPACE_BYTES = 64 << 20
# serve reads a prompt in segments of this many rows at most (q38_serve_prefill:
# coli_prompt_segment_rows, 8192 with a dense chain, 2048 without), so a forward's
# row buffers hold one segment, not the context. COLI_PROMPT_SEGMENT sets both.
_QWEN38_PROMPT_SEGMENT_ROWS = 8192


def _qwen38_prompt_rows(context):
    """The most rows one forward holds: the context, or serve's prompt segment."""
    try:
        segment = int(os.environ.get("COLI_PROMPT_SEGMENT", "") or 0)
    except ValueError:
        segment = 0
    return min(context, segment if segment > 0 else _QWEN38_PROMPT_SEGMENT_ROWS)


def _qwen38_bounded_prefill(rows, fixed_bytes, row_bytes):
    """Mirror q38_bounded_prefill_rows() without context-sized scratch."""
    selected = min(rows, _QWEN38_PREFILL_BATCH_ROWS)
    while selected > 1 and fixed_bytes + selected * row_bytes > \
            _QWEN38_PREFILL_WORKSPACE_BYTES:
        selected -= 1
    return selected


def _qwen38_geometry(config, context, _model_dir):
    """Qwen3.8-Flash-Next's hybrid state layout.

    Full-attention layers retain GQA K/V plus the raw QSA index key.  Linear
    (GDN) layers retain a recurrent matrix and a four-stream convolution ring;
    the single PLE layer adds its own convolution history and two int64 ngram
    history positions.  Hyper-connection streams also contribute to prefill
    scratch, so workspace is deliberately conservative rather than zero.
    """
    family = "qwen38"
    layers = _required_int(config, "num_hidden_layers", family)
    hidden = _required_int(config, "hidden_size", family)
    vocab = _required_int(config, "vocab_size", family)
    max_positions = _required_int(config, "max_position_embeddings", family)
    eos = _required_int(config, "eos_token_id", family, 0)
    if layers > 512 or hidden > 65536 or max_positions > 262144 or eos >= vocab:
        raise ValueError(f"{family}: model dimensions exceed the native engine limits")
    if context > max_positions:
        raise ValueError(f"{family}: context {context} exceeds max_position_embeddings "
                         f"{max_positions}")
    kinds = config.get("layer_types")
    if not isinstance(kinds, list) or len(kinds) != layers:
        raise ValueError(f"{family}: missing or invalid planning key 'layer_types'")
    # Upstream calls these ``full_attention``; early Qwen4-Exp exports and the
    # tiny oracle call the same QSA layer ``qwen_sparse_attention``.
    allowed_kinds = {"linear_attention", "full_attention", "qwen_sparse_attention"}
    unknown_kinds = sorted({kind for kind in kinds if kind not in allowed_kinds})
    if unknown_kinds:
        raise ValueError(f"{family}: unsupported layer types {unknown_kinds!r}")
    full = sum(kind in ("full_attention", "qwen_sparse_attention") for kind in kinds)
    linear = layers - full

    n_kv = _required_int(config, "num_key_value_heads", family)
    head_dim = _required_int(config, "head_dim", family)
    q_heads = _required_int(config, "num_attention_heads", family)
    if q_heads % n_kv:
        raise ValueError(f"{family}: attention heads are not divisible by KV heads")
    rope = config.get("rope_parameters")
    rope = rope if isinstance(rope, dict) else config
    partial = rope.get("partial_rotary_factor", config.get("partial_rotary_factor", 1.0))
    if (isinstance(partial, bool) or not isinstance(partial, (int, float)) or
            not math.isfinite(partial) or not 0 < partial <= 1):
        raise ValueError(f"{family}: invalid partial_rotary_factor")
    rotary_dim = int(head_dim * partial)
    if rotary_dim < 1 or rotary_dim > head_dim or rotary_dim % 2:
        raise ValueError(f"{family}: invalid derived rotary dimension")
    index_kv = _required_int(config, "indexer_kv_heads", family)
    index_dim = _required_int(config, "indexer_head_dim", family)
    index_q = _required_int(config, "indexer_n_heads", family)
    index_budget = _required_int(config, "indexer_budget", family)
    index_ratio = _required_int(config, "indexer_compress_ratio", family)
    if index_kv != 1 or index_dim < rotary_dim or index_budget % index_ratio:
        raise ValueError(f"{family}: invalid sparse indexer geometry")
    # Serve allocates this complete QSA bank once before publishing READY and
    # never grows it in place. One context-sized bank is therefore both the
    # steady allocation and the allocation peak; no old/new growth pair exists.
    context_state = full * context * (2 * n_kv * head_dim + index_kv * index_dim) * 4

    value_heads = _required_int(config, "linear_num_value_heads", family)
    key_dim = _required_int(config, "linear_key_head_dim", family)
    value_dim = _required_int(config, "linear_value_head_dim", family)
    hc_count = _required_int(config, "hc_count", family)
    hc_rank = _required_int(config, "hc_lowrank", family)
    if hc_count > 16 or hc_rank > 65536:
        raise ValueError(f"{family}: invalid hyper-connection geometry")
    key_heads = _required_int(config, "linear_num_key_heads", family)
    gdn_conv = _required_int(config, "linear_conv_kernel_dim", family, 2) - 1
    if value_heads % key_heads or value_dim > 512:
        raise ValueError(f"{family}: invalid Gated DeltaNet geometry")
    gdn_conv_width = (2 * key_heads * key_dim + value_heads * value_dim)
    fixed = linear * (value_heads * key_dim * value_dim +
                      gdn_conv_width * gdn_conv) * 4

    ple_ids = config.get("ple_layer_ids", [])
    if (not isinstance(ple_ids, list) or len(ple_ids) != 1 or
            isinstance(ple_ids[0], bool) or not isinstance(ple_ids[0], int) or
            not 1 <= ple_ids[0] <= layers):
        raise ValueError(f"{family}: invalid planning key 'ple_layer_ids'")
    ple_conv = _required_int(config, "ple_conv_kernel_size", family, 2) - 1
    ngram = _required_int(config, "ngram_size", family, 2)
    heads_per_ngram = _optional_int(config, "heads_per_ngram", 8, 1)
    ngram_heads = (ngram - 1) * heads_per_ngram
    ple_dim = _required_int(config, "ple_embed_dim", family)
    ngram_parts = _optional_int(config, "split_ngram_parts", 1, 1)
    if (ngram != 3 or not 1 <= ngram_heads <= 64 or ple_dim % ngram_heads or
            ple_dim // ngram_heads > 512 or ngram_parts > 512):
        raise ValueError(f"{family}: invalid PLE geometry")
    # PLE's retained convolution ring is per hyper-connection stream: the
    # runtime allocates hc_count * hidden, not the projection embed dimension.
    hc_width = hc_count * hidden
    fixed += len(ple_ids) * (hc_width * ngram * ple_conv * 4 +
                             (ngram - 1) * 8)

    # The one-slot serve path keeps an exact prompt-prefix checkpoint. QSA rows
    # remain in their existing append-only cache, while every recurrent/PLE
    # payload is copied once so decode can mutate the live state without
    # damaging the reusable prompt. It also retains the prompt token IDs and
    # final prompt logits. The adapter/runtime base reserve covers allocator and
    # pointer metadata; these are the complete model-sized payloads.
    prefix_snapshot = fixed + vocab * 4
    fixed += prefix_snapshot
    context_state += context * 4

    # Match the peak buffers held concurrently by step(): the persistent
    # hyper/mixed/inject/block rows plus the largest layer-local row set. The
    # base planner reserve still covers allocator and non-scaling overhead.
    base_row = hc_width + 2 * hidden + hc_count
    gated_residual_row = base_row + 2 * hc_width + hc_rank
    qsa_row = (base_row + 2 * q_heads * head_dim + 2 * n_kv * head_dim +
               (index_q + index_kv) * index_dim + q_heads * head_dim)
    ple_row = base_row + hc_width

    experts = _required_int(config, "num_experts", family)
    topk = _required_int(config, "num_experts_per_tok", family)
    if experts > 1024 or topk > 256 or topk > experts:
        raise ValueError(f"{family}: invalid routed-expert geometry")
    intermediate = _required_int(config, "moe_intermediate_size", family)
    shared = _required_int(config, "shared_expert_intermediate_size", family)
    moe_fixed = experts + 3 * shared + 3 * intermediate + 2 * hidden
    gdn_fixed = (2 * gdn_conv_width + 3 * value_heads * value_dim +
                 2 * value_heads + 2 * value_heads * key_dim)
    ple_fixed = ple_dim + 5 * hc_width + hidden
    qsa_fixed = (index_q * index_dim + index_dim + index_budget + index_ratio - 1 +
                 max(2 * (context // index_ratio),
                     head_dim + index_budget + index_ratio - 1))
    # The outer rows of one forward: serve's prompt segment, not the whole context (a
    # 262144-token context priced as one forward held 38 GB that serve never takes).
    rows = _qwen38_prompt_rows(context)
    workspace = (rows * max(gated_residual_row, qsa_row, ple_row) +
                 max(moe_fixed, gdn_fixed, ple_fixed, qsa_fixed)) * 4

    # q38_moe_prefill() and q38_deltanet() batch only a bounded row chunk.
    # Account their exact simultaneous allocations beside the context-sized
    # outer hyper/mixed/inject/block rows. Q38RouteAssignment is one int plus
    # one float (8 bytes), and supported hosts use 64-bit pointers.
    moe_assignment_bytes = 2 * (hidden + intermediate) * 4 + 8 + 2 * 4
    moe_row_bytes = (experts + 3 * shared + hidden + 1) * 4 + \
        topk * moe_assignment_bytes
    moe_fixed_bytes = experts * (4 * 4 + 8) + 4
    moe_rows = _qwen38_bounded_prefill(
        rows, moe_fixed_bytes, moe_row_bytes)
    moe_chunk_bytes = moe_fixed_bytes + moe_rows * moe_row_bytes

    delta_row_bytes = (gdn_conv_width + 2 * value_heads * value_dim +
                       2 * value_heads) * 4
    delta_fixed_bytes = (gdn_conv_width +
                         2 * value_heads * key_dim +
                         value_heads * value_dim) * 4
    delta_rows = _qwen38_bounded_prefill(
        rows, delta_fixed_bytes, delta_row_bytes)
    delta_chunk_bytes = delta_fixed_bytes + delta_rows * delta_row_bytes
    prefill_workspace = rows * base_row * 4 + max(
        moe_chunk_bytes, delta_chunk_bytes)
    workspace = max(workspace, prefill_workspace)
    return PlannerGeometry(context_state, fixed, workspace,
                           experts)


def _olmoe_geometry(config, context, _model_dir):
    """Conventional full multi-head attention: every layer holds a K and a V
    cache in fp32, and olmoe.c sizes both at num_attention_heads * head_dim, not
    num_key_value_heads (`c/olmoe.c:1019-1020`, with head_dim = hidden_size //
    num_attention_heads at `:327`). There is no recurrent or convolutional state,
    and the KV cache is the only buffer that grows with context, so fixed and
    workspace are zero -- the bounded per-forward scratch (attention scores,
    logits, expert temporaries) is already covered by the base runtime reserve."""
    layers = _required_int(config, "num_hidden_layers", "olmoe")
    hidden = _required_int(config, "hidden_size", "olmoe")
    heads = _required_int(config, "num_attention_heads", "olmoe")
    head_dim = hidden // heads
    if head_dim < 1:
        raise ValueError("olmoe: hidden_size is smaller than num_attention_heads")
    experts = _required_int(config, "num_experts", "olmoe")
    state = layers * context * heads * head_dim * 2 * 4
    return PlannerGeometry(state, 0, 0, experts)



def _kimi_geometry(config, context, _model_dir):
    """Kimi K3: hybrid -- 69 KDA (recurrent) + 24 gated MLA layers.

    The engine marks KDA layers via linear_attn_config.kda_layers (1-based
    indices, kimi_k3.c:552-555); every other layer is a gated MLA layer.
    Only the MLA layers keep a positional Lc/Rc cache (kimi_k3.c:1704-1706),
    so only they scale with context:

        MLA cache = n_mla * context * (kv_lora + qk_rope) * 4

    The KDA layers carry a per-head recurrent state that does NOT depend on
    context (kimi_k3.c:691): kda_heads * kda_hd * kda_hd floats per layer.
    That belongs in fixed_state_bytes, exactly like GLM's indexer state.

    Workspace mirrors the prefill temporary set (C == context):
      KDA (kimi_k3.c:896-898): q,k,v,gp,on,graw = 6*C*P, t1 = C*kda_hd,
                               braw = C*hidden, P = kda_heads*kda_hd
      MLA (kimi_k3.c:992-994): qa = C*q_lora, qv = C*H*qh, ckv = C*(kvl+qr),
                               gv = C*H*vh, ctx = C*H*vh
    The planner reserves the larger of the two (a single forward pass only
    touches one layer type at a time).

    Kimi K3.1 (dsa_config): every DSA layer also keeps its indexer's keys,
    index_head_dim floats a position (kimi_k3.c's Ic):

        index keys = n_dsa * context * index_head_dim * 4
    """
    layers = _required_int(config, "num_hidden_layers", "kimi_k3")
    experts = _required_int(config, "num_experts", "kimi_k3")
    hidden = _required_int(config, "hidden_size", "kimi_k3")
    heads = _required_int(config, "num_attention_heads", "kimi_k3")
    q_lora = _required_int(config, "q_lora_rank", "kimi_k3")
    kv_lora = _required_int(config, "kv_lora_rank", "kimi_k3")
    qk_nope = _required_int(config, "qk_nope_head_dim", "kimi_k3")
    qk_rope = _required_int(config, "qk_rope_head_dim", "kimi_k3")
    v_head = _required_int(config, "v_head_dim", "kimi_k3")

    la = config.get("linear_attn_config")
    if not isinstance(la, dict):
        raise ValueError("kimi_k3: missing or invalid planning key 'linear_attn_config'")
    kda_heads = _required_int(la, "num_heads", "kimi_k3")
    kda_hd = _required_int(la, "head_dim", "kimi_k3")
    kda_list = la.get("kda_layers")
    if not isinstance(kda_list, list):
        raise ValueError("kimi_k3: missing or invalid planning key 'linear_attn_config.kda_layers'")
    n_kda = sum(1 for v in kda_list if isinstance(v, int) and 1 <= v <= layers)
    n_mla = layers - n_kda
    if n_mla < 0:
        n_mla = 0

    state = n_mla * context * (kv_lora + qk_rope) * 4
    dsa = config.get("dsa_config")
    if isinstance(dsa, dict):
        index_hd = _required_int(dsa, "index_head_dim", "kimi_k3")
        dsa_list = dsa.get("dsa_layers")
        if not isinstance(dsa_list, list):
            raise ValueError("kimi_k3: missing or invalid planning key 'dsa_config.dsa_layers'")
        n_dsa = sum(1 for v in dsa_list if isinstance(v, int) and 1 <= v <= layers)
        state += n_dsa * context * index_hd * 4
    fixed = n_kda * kda_heads * kda_hd * kda_hd * 4

    kda_proj = kda_heads * kda_hd
    ws_kda = context * (6 * kda_proj + kda_hd + hidden) * 4
    qh = qk_nope + qk_rope
    ws_mla = context * (q_lora + heads * qh + kv_lora + qk_rope +
                        2 * heads * v_head) * 4
    workspace = max(ws_kda, ws_mla)
    return PlannerGeometry(state, fixed, workspace, experts)



# Il default di GLM53_PREFILL_CHUNK in glm53.c. Se cambia li', cambia qui:
# e' una costante con due consumatori.
_GLM53_PREFILL_CHUNK = 128


def _glm53_dense_in_ram(on_disk_bytes):
    """I densi di GLM-5.3 non restano come sul disco.

    Il checkpoint li porta in BF16 e il motore li quantizza al caricamento
    secondo GLM53_BITS (default 4), che e' int4 con una scala ogni 64 colonne:
    0,5625 byte per parametro contro i 2 del file. Contarli come stanno su
    disco fa dire al pianificatore che manca RAM per un solo esperto per layer,
    quando ce ne stanno diciassette."""
    import os
    try:
        bits = int(os.environ.get("GLM53_BITS", "4"))
    except ValueError:
        bits = 4
    per_parameter = {4: 0.5625, 8: 1.0, 32: 4.0}.get(bits, 0.5625)
    return int(on_disk_bytes * per_parameter / 2.0)      # il file e' BF16


def _glm53_geometry(config, context, _model_dir):
    """GLM-5.3-Flash: 34 layer KDA ricorrenti piu' 11 layer MLA con DSA.

    Solo i layer DSA crescono col contesto, e crescono meno di quanto sembri:
    il motore assorbe kv_b_proj (glm53.c, absorb_kvb), quindi in cache finisce
    il latente da kv_lora e non chiavi e valori espansi. Con 64 teste a 256 la
    differenza e' fra 33 KB e 1,39 MB per token. Ai latenti si aggiungono le
    chiavi e i gate dell'indexer, due vettori da index_head_dim per posizione.

    I layer KDA portano uno stato ricorrente che NON dipende dal contesto, piu'
    la finestra della convoluzione corta: entrambi vanno nel fisso.

    Lo spazio di lavoro NON scala col contesto: il prefill va a pezzi da
    GLM53_PREFILL_CHUNK (glm53.c, forward_prefill), quindi i temporanei costano
    quanto un pezzo. Il costo che domina dentro al pezzo non e' l'attenzione ma
    i flussi delle hyper-connections, hc_mult copie del residuo per posizione,
    tenute due volte perche' il passaggio le scambia.
    """
    layers = _required_int(config, "num_hidden_layers", "glm5_next")
    experts = _required_int(config, "n_routed_experts", "glm5_next")
    hidden = _required_int(config, "hidden_size", "glm5_next")
    heads = _required_int(config, "num_attention_heads", "glm5_next")
    q_lora = _required_int(config, "q_lora_rank", "glm5_next")
    kv_lora = _required_int(config, "kv_lora_rank", "glm5_next")
    qk_nope = _required_int(config, "qk_nope_head_dim", "glm5_next")
    v_head = _required_int(config, "v_head_dim", "glm5_next")
    index_hd = _required_int(config, "index_head_dim", "glm5_next")
    hc_mult = _required_int(config, "hc_mult", "glm5_next")

    la = config.get("linear_attn_config")
    if not isinstance(la, dict):
        raise ValueError("glm5_next: missing or invalid planning key 'linear_attn_config'")
    kda_heads = _required_int(la, "num_heads", "glm5_next")
    kda_hd = _required_int(la, "head_dim", "glm5_next")
    kernel = _required_int(la, "short_conv_kernel_size", "glm5_next")

    # Quali layer sono ad attenzione piena: il checkpoint lo dice in due modi e
    # devono concordare, altrimenti non si sa quale credere.
    types = config.get("layer_types")
    full_list = la.get("full_attn_layers")
    if isinstance(types, list) and types:
        n_full = sum(1 for t in types if isinstance(t, str) and "linear" not in t)
    elif isinstance(full_list, list):
        n_full = len(full_list)
    else:
        raise ValueError("glm5_next: missing 'layer_types' and 'linear_attn_config.full_attn_layers'")
    n_kda = layers - n_full
    if n_kda < 0:
        n_kda = 0

    state = n_full * context * (kv_lora + 2 * index_hd) * 4
    kda_proj = kda_heads * kda_hd
    fixed = n_kda * (kda_heads * kda_hd * kda_hd + 3 * kda_proj * kernel) * 4

    # prefill: due banchi di flussi residui, piu' i temporanei del layer piu'
    # caro fra KDA e MLA (un passaggio ne tocca uno solo per volta)
    chunk = _GLM53_PREFILL_CHUNK
    ws_streams = 2 * chunk * hc_mult * hidden * 4
    ws_kda = chunk * (6 * kda_proj + kda_hd + hidden) * 4
    ws_mla = chunk * (q_lora + heads * (qk_nope + kv_lora) + 2 * heads * v_head) * 4
    workspace = ws_streams + max(ws_kda, ws_mla)
    return PlannerGeometry(state, fixed, workspace, experts)


def _inkling_local_layers(config, layers):
    """Which Inkling layers are sliding-window (1-based rule from inkling.c:557-568).

    Precedence, mirroring the engine:
      1. explicit ``layer_types`` array ("hybrid_sliding" marks local layers)
      2. ``local_layer_ids`` array of 0-based layer indices
      3. the default ``(i + 1) % 6 != 0`` rule (5 of every 6 layers sliding)
    """
    lt = config.get("layer_types")
    if isinstance(lt, list):
        if len(lt) != layers:
            raise ValueError("inkling: layer_types length must match num_hidden_layers")
        return [t == "hybrid_sliding" for t in lt]
    ll = config.get("local_layer_ids")
    if isinstance(ll, list):
        local = [False] * layers
        for v in ll:
            if isinstance(v, int) and 0 <= v < layers:
                local[v] = True
        return local
    return [(i + 1) % 6 != 0 for i in range(layers)]


def _inkling_geometry(config, context, _model_dir):
    """Inkling: hybrid GQA -- sliding-window layers (window ring) + global layers
    + short convolutions (sconv) on K/V/attn/mlp + optional DMel audio tower.

    Mirrors the engine's allocation in inkling.c:

    KV cache (kv_alloc, inkling.c:1687-1699): every layer keeps its own
    K/V pair sized from the layer's kv heads and head dim (L_KV/L_HD,
    inkling.c:80-82). Sliding layers are a ring of ``window`` rows
    (kv_ring_rows, inkling.c:1124-1125) -- at context > window that is a
    ~64x cut on 5-of-6 layers; global layers keep the full context.

        state[layer] = 2 * kv * rows * hd * 4,  rows = window | context

    Conv states (inkling.c:888-890, 1646): four depthwise short-conv states
    per layer -- cs[0]/cs[1] are kv-wide (kvdim), cs[2]/cs[3] are hidden-wide
    -- each holding ``conv_k - 1`` history rows. These do not scale with
    context, so they are fixed_state_bytes.

        fixed[layer] = (2 * kvdim + 2 * hidden) * (conv_k - 1) * 4

    Workspace (attention temporaries, inkling.c:1141-1147): q, k, vv, rr
    and ctx are per-batch S buffers; with S == context at prefill the peak
    is the maximum across layer types (global vs sliding differ).

        ws = S * (2 * qdim + 2 * kvdim + H * d_rel) * 4

    Audio tower (inkling.c:808-832): a DMel encoder embedding table
    [mel_bins * mel_vocab, hidden] plus one RMSNorm weight. It is a fixed
    resident allocation when ``audio_config`` is present, so it joins
    fixed_state_bytes.
    """
    layers = _required_int(config, "num_hidden_layers", "inkling")
    experts = _required_int(config, "n_routed_experts", "inkling")
    hidden = _required_int(config, "hidden_size", "inkling")
    heads = _required_int(config, "num_attention_heads", "inkling")
    n_kv = _required_int(config, "num_key_value_heads", "inkling")
    head_dim = _required_int(config, "head_dim", "inkling")
    swa_heads = _optional_int(config, "swa_num_attention_heads", heads, 1)
    swa_kv = _optional_int(config, "swa_num_key_value_heads", n_kv, 1)
    swa_hd = _optional_int(config, "swa_head_dim", head_dim, 1)
    window = _optional_int(config, "sliding_window_size", 512, 1)
    d_rel = _optional_int(config, "d_rel", 16, 1)
    conv_k = _optional_int(config, "sconv_kernel_size",
                           _optional_int(config, "conv_kernel_size", 4, 1), 1)

    local = _inkling_local_layers(config, layers)
    if len(local) != layers:
        raise ValueError("inkling: layer_types length must match num_hidden_layers")

    state = 0
    fixed = 0
    workspace = 0
    for i in range(layers):
        kv = swa_kv if local[i] else n_kv
        hd = swa_hd if local[i] else head_dim
        h = swa_heads if local[i] else heads
        rows = window if (local[i] and window > 0 and window < context) else context
        state += 2 * kv * rows * hd * 4
        kvdim = kv * hd
        fixed += (2 * kvdim + 2 * hidden) * (conv_k - 1) * 4
        qdim = h * hd
        ws = context * (2 * qdim + 2 * kvdim + h * d_rel) * 4
        workspace = max(workspace, ws)

    ac = config.get("audio_config")
    if isinstance(ac, dict):
        mel_bins = _optional_int(ac, "n_mel_bins", 80, 1)
        mel_vocab = _optional_int(ac, "mel_vocab_size", 16, 1)
        fixed += (mel_bins * mel_vocab * hidden + hidden) * 4

    return PlannerGeometry(state, fixed, workspace, experts)



def _dsv4_geometry(config, context, _model_dir):
    """DeepSeek V4: sliding-window ring + per-layer compressor/indexer states.

    Mirrors the engine's own ``context_bytes()`` (deepseek_v4.c:1271-1284)
    exactly -- this is the resident cache the C runtime sizes at load:

        base       = num_hidden_layers * sliding_window * head_dim * 4
        per layer: ratio = compress_ratios[layer]
                   compressed = ceil(context / ratio)
                   total += compressed * head_dim * 4
                   if ratio == 4:
                       total += compressed * index_head_dim * 4

    The window ring (``base``) does not depend on the context: it is a fixed
    circular buffer, so it belongs in fixed_state_bytes. The compressor and
    indexer states scale with ``context / ratio`` and belong in
    context_state_bytes.

    Workspace mirrors the batched-attention scratch set
    (deepseek_v4.c:2741-2750): qa (q_rank), q (q_width), kv (head_dim),
    attended (q_width), oa (oa_width), norm (max(q_rank, head_dim)) -- with
    q_width = heads * head_dim and oa_width = o_groups * o_lora_rank. With
    batch == context at prefill the peak is the sum of the batch-wide float
    buffers plus the single norm buffer.

    Experts: configured_experts = n_routed_experts.
    """
    layers = _required_int(config, "num_hidden_layers", "deepseek_v4")
    experts = _required_int(config, "n_routed_experts", "deepseek_v4")
    _required_int(config, "hidden_size", "deepseek_v4")
    heads = _required_int(config, "num_attention_heads", "deepseek_v4")
    head_dim = _required_int(config, "head_dim", "deepseek_v4")
    q_rank = _required_int(config, "q_lora_rank", "deepseek_v4")
    o_groups = _required_int(config, "o_groups", "deepseek_v4")
    o_rank = _required_int(config, "o_lora_rank", "deepseek_v4")
    window = _required_int(config, "sliding_window", "deepseek_v4")
    index_hd = _required_int(config, "index_head_dim", "deepseek_v4")

    ratios = config.get("compress_ratios")
    if not isinstance(ratios, list) or len(ratios) < layers:
        raise ValueError(
            "deepseek_v4: compress_ratios must be a list of at least "
            "num_hidden_layers entries")

    # Fixed window ring: n_layers * window * head_dim fp32.
    fixed = layers * window * head_dim * 4

    # Compressor + indexer states, scaling with context / ratio.
    state = 0
    for ratio in ratios[:layers]:
        if not isinstance(ratio, bool) and isinstance(ratio, int) and ratio > 0:
            compressed = (context + ratio - 1) // ratio
            state += compressed * head_dim * 4
            if ratio == 4:
                state += compressed * index_hd * 4
        elif ratio != 0:
            raise ValueError("deepseek_v4: compress_ratios entries must be "
                             "non-negative integers")

    # Batched-attention scratch (prefill, batch == context).
    q_width = heads * head_dim
    oa_width = o_groups * o_rank
    workspace = (context * (q_rank + 2 * q_width + head_dim + oa_width) +
                 max(q_rank, head_dim)) * 4

    return PlannerGeometry(state, fixed, workspace, experts)


def _dsv41_geometry(config, context, _model_dir):
    """DeepSeek V4.1 Flash: window ring, compressed KV and index keys, engram rows.

    What the engine keeps resident per layer (deepseek_v41.c model_load):

        window ring   n_layers * window_size * head_dim * 4      (fixed)
        compressed KV ceil(context / ratio) * head_dim * 4       (per kv source)
        index keys    ceil(context / ratio) * index_head_dim * 4 (per kv source)

    The engram tables are NOT in here on purpose: 203 GB of the released
    checkpoint is n-gram memory read row by row from disk (264 bytes per row,
    at most (max_ngram - 1) * n_heads rows per layer per token), with a small
    LRU whose size is a runtime knob rather than a function of the context.
    Counting them as resident would tell a user with 128 GB that this model
    cannot be served, which is the opposite of true.

    Workspace mirrors forward()'s per-chunk buffers: hc_mult residual copies
    plus the sublayer scratch, at batch == context.
    """
    section = config.get("text_config", config)
    layers = _required_int(section, "num_hidden_layers", "deepseek_v41")
    experts = _required_int(section, "n_routed_experts", "deepseek_v41")
    hidden = _required_int(section, "hidden_size", "deepseek_v41")
    head_dim = _required_int(section, "head_dim", "deepseek_v41")
    window = _required_int(section, "sliding_window", "deepseek_v41") \
        if "sliding_window" in section else _required_int(section, "window_size", "deepseek_v41")
    index_hd = _required_int(section, "index_head_dim", "deepseek_v41")
    hc_mult = _required_int(section, "hc_mult", "deepseek_v41")

    ratios = section.get("compress_ratios")
    if not isinstance(ratios, list) or len(ratios) < layers:
        raise ValueError("deepseek_v41: compress_ratios must be a list of at least "
                         "num_hidden_layers entries")
    sources = section.get("kv_source_layer_ids") or section.get("kv_source_layers") or []
    if not isinstance(sources, list):
        raise ValueError("deepseek_v41: kv_source_layer_ids must be a list")

    # The DSpark stages keep a window ring each, on the same terms as a layer: their
    # attention is window-only, and the window holds the main stream's keys.
    stages = section.get("n_mtp_layers") or 0
    if not isinstance(stages, int) or isinstance(stages, bool) or stages < 0:
        raise ValueError("deepseek_v41: n_mtp_layers must be a non-negative integer")
    fixed = (layers + stages) * window * head_dim * 4
    state = 0
    for layer in sources:
        if not isinstance(layer, int) or isinstance(layer, bool) or not 0 <= layer < layers:
            raise ValueError("deepseek_v41: kv_source_layer_ids entries must index a layer")
        ratio = ratios[layer]
        if not isinstance(ratio, int) or isinstance(ratio, bool) or ratio < 1:
            raise ValueError("deepseek_v41: a kv source layer must compress")
        compressed = (context + ratio - 1) // ratio
        state += compressed * (head_dim + index_hd) * 4

    workspace = (context * hc_mult * hidden * 2 + context * hidden * 2 + hidden) * 4
    return PlannerGeometry(state, fixed, workspace, experts)


def _mimo_geometry(config, context, _model_dir):
    """MiMo-V2.6: what mimo.c allocates per context (kv_alloc), in f32.

        full-attention layers  context * kv_heads * (head_dim + v_head_dim) * 4
        sliding-window layers  min(window, context) * swa_kv_heads * (swa_head_dim +
                               swa_v_head_dim) * 4, a ring that never grows (fixed)

    hybrid_layer_pattern says which is which (1 = sliding window). On Flash 39 of
    the 48 layers are windowed, so a 1M context costs the KV of 9 layers.
    Workspace mirrors forward()'s per-block buffers at the default 64-row block,
    plus the full-attention score row per head.
    """
    layers = _required_int(config, "num_hidden_layers", "mimo")
    experts = _required_int(config, "n_routed_experts", "mimo")
    hidden = _required_int(config, "hidden_size", "mimo")
    kv = _required_int(config, "num_key_value_heads", "mimo")
    head_dim = _required_int(config, "head_dim", "mimo")
    v_dim = config.get("v_head_dim", head_dim)
    swa_kv = config.get("swa_num_key_value_heads", kv)
    swa_hd = config.get("swa_head_dim", head_dim)
    swa_vd = config.get("swa_v_head_dim", v_dim)
    heads = _required_int(config, "num_attention_heads", "mimo")
    for name, value in (("v_head_dim", v_dim), ("swa_num_key_value_heads", swa_kv),
                        ("swa_head_dim", swa_hd), ("swa_v_head_dim", swa_vd)):
        if not isinstance(value, int) or isinstance(value, bool) or value < 1:
            raise ValueError(f"mimo: {name} must be a positive integer")
    pattern = config.get("hybrid_layer_pattern")
    if not isinstance(pattern, list) or len(pattern) != layers:
        raise ValueError("mimo: hybrid_layer_pattern must list every layer")
    windowed = sum(1 for kind in pattern if kind == 1)
    window = _required_int(config, "sliding_window", "mimo") if windowed else 0
    state = (layers - windowed) * context * kv * (head_dim + v_dim) * 4
    fixed = windowed * min(window, context) * swa_kv * (swa_hd + swa_vd) * 4
    block = 64
    workspace = (block * hidden * 6 + block * heads * (head_dim + v_dim) * 2
                 + heads * context) * 4
    return PlannerGeometry(state, fixed, workspace, experts)


# What the plan does not count: the MTP layers (mimo.c drafts with Pro's first
# two, 0.8 GB each, and does not read Flash's) and the audio encoder, which it
# never loads (text and images only).
_MIMO_NOT_LOADED = re.compile(r"^(?:model\.mtp\.|audio_encoder\.|speech_embeddings\.)")


def _mimo_expert_inventory(name, size, _config, _dtype=None):
    match = _GLM_EXPERT.search(name)
    if match is None or name.startswith("model.mtp."):
        return ()
    return ((int(match.group(1)), int(match.group(2)), size),)


def _mimo_resident_inventory(name, size, _config, _dtype=None):
    return 0 if _MIMO_NOT_LOADED.match(name) else size


_DSV41_MTP_EXPERT = re.compile(r"^mtp\.(\d+)\.ffn\.experts\.(\d+)\.")


_GLM_EXPERT = re.compile(
    r"(?:^|\.)model\.layers\.(\d+)\.mlp\.experts\.(\d+)\."
)
_KIMI_EXPERT = re.compile(
    r"^(?:language_model\.)?model\.layers\.(\d+)\.block_sparse_moe\."
    r"experts\.(\d+)\."
)
_V4_EXPERT = re.compile(r"^layers\.(\d+)\.ffn\.experts\.(\d+)\.")
_GLM53_EXPERT = re.compile(
    r"^model\.(?:language_model\.)?layers\.(\d+)\.mlp\.experts\.(\d+)\."
)
_INKLING_EXPERT = re.compile(
    r"^model\.layers\.(\d+)\.mlp\.experts\."
    r"(?:gate_up_proj|down_proj)(?:\.|$)"
)
_QWEN38_EXPERT = re.compile(
    r"^(?:model\.)?(?:language_model\.)?layers\.(\d+)\.mlp\.experts\."
    r"(\d+)\.(gate_proj|up_proj|down_proj)\.weight$"
)
_QWEN38_EXPERT_SCALE = re.compile(
    r"^(?:model\.)?(?:language_model\.)?layers\.(\d+)\.mlp\.experts\."
    r"(\d+)\.(gate_proj|up_proj|down_proj)\.weight_scale_inv$"
)
_QWEN38_FUSED_EXPERT = re.compile(
    r"^(?:model\.)?(?:language_model\.)?layers\.(\d+)\.mlp\.experts\."
    r"(gate_up_proj|down_proj)$"
)


def _individual_expert_inventory(pattern):
    def inventory(name, size, _config, _dtype=None):
        match = pattern.search(name)
        if match is None:
            return ()
        return ((int(match.group(1)), int(match.group(2)), size),)
    return inventory


def _dsv41_expert_inventory(name, size, config, _dtype=None):
    """Routed experts, the backbone's and the DSpark head's alike.

    A draft stage streams its experts exactly as a layer does -- its own LRU, its own
    smaller set -- so they belong in the expert inventory and not in the resident
    weights, where three stages of 128 experts would be 7 GB of RAM the engine never
    holds. They are filed after the last real layer, which is where the vendor's own
    numbering puts them: `DSparkBlock(args.n_layers + stage_id, args)`. The planner
    then prices one cache slot per stage, which is what the engine allocates.
    """
    match = _V4_EXPERT.search(name)
    if match is not None:
        return ((int(match.group(1)), int(match.group(2)), size),)
    match = _DSV41_MTP_EXPERT.search(name)
    if match is None:
        return ()
    section = config.get("text_config", config)
    layers = section.get("num_hidden_layers")
    if not isinstance(layers, int) or isinstance(layers, bool) or layers < 1:
        raise ValueError("deepseek_v41: num_hidden_layers is required to place the "
                         "DSpark stages after the backbone")
    return ((layers + int(match.group(1)), int(match.group(2)), size),)


# a table as the checkpoint's two tensors, or a GGUF's one (blk.N.engram_embd, each row its
# e4m3 then its scales: _gguf_tensor_sizes renames only the experts)
_DSV41_ENGRAM = re.compile(r"^(?:layers\.(\d+)\.engram\.embed\.(weight|scale)|blk\.(\d+)\.engram_embd\.weight"
                           r"|per_layer_token_embd\.weight|engram\.embed\.weight)$")   # the published GGUFs': every table in one


def _dsv41_resident_inventory(name, size, _config, _dtype=None):
    """Resident bytes for what the engine actually holds in RAM.

    The two n-gram tables are 203 GB of the released checkpoint, 40% of it, and
    the engine never holds them: it reads one 264-byte row at a time from disk
    behind a small LRU whose size is a runtime knob. Counted as dense they turn
    a 552B model that fits a workstation into one that needs 214 GB of RAM, and
    the plan then plans nothing: measured against the real checkpoint on a 61 GB
    box, `coli plan` reported 214.3 GB of dense weights, 0% projected expert
    residency and a cap of zero, for a model whose resident trunk is 11 GB.
    """
    return 0 if _DSV41_ENGRAM.match(name) else size


def _inkling_expert_inventory(name, size, config, _dtype=None):
    match = _INKLING_EXPERT.fullmatch(name)
    if match is None:
        return ()
    experts = _required_int(config, "n_routed_experts", "inkling")
    if size % experts:
        raise ValueError(f"inkling: fused expert tensor {name!r} is not divisible "
                         f"by {experts} experts")
    per_expert = size // experts
    layer = int(match.group(1))
    return tuple((layer, expert, per_expert) for expert in range(experts))


def _qwen38_expert_inventory(name, size, config, dtype=None):
    """Index per-expert FP8 and fused BF16 expert tensor layouts.

    Resource planning calls this once per tensor; summing the returned byte
    counts therefore combines gate/up and down tensors for each expert without
    multiplying either tensor by the expert count a second time. FP8 scale
    sidecars are validated here but accounted for by the fixed resident
    inventory because the native loader shares their normalized bank.
    """
    match = _QWEN38_EXPERT.fullmatch(name)
    if match and isinstance(dtype, str) and dtype.startswith("GGUF_"):
        # a tools/gguf_import.py directory: the engine keeps each expert's ggml
        # blocks as the file has them (q38_gg_read_expert), so a slot costs their bytes
        return ((int(match.group(1)), int(match.group(2)), size),)
    if match:
        hidden = _required_int(config, "hidden_size", "qwen38")
        intermediate = _required_int(config, "moe_intermediate_size", "qwen38")
        elements = hidden * intermediate
        if size not in (elements, elements * 2, elements * 4):
            raise ValueError(f"qwen38: expert tensor {name!r} has unexpected size {size}")
        inferred = {elements: "F8_E4M3", elements * 2: "BF16",
                    elements * 4: "F32"}[size]
        dtype = inferred if dtype is None else dtype
        expected = {"F8_E4M3": elements, "F8_E4M3FN": elements,
                    "float8_e4m3fn": elements, "BF16": elements * 2,
                    "F16": elements * 2, "F32": elements * 4}.get(dtype)
        if expected != size:
            raise ValueError(f"qwen38: expert tensor {name!r} has unsupported "
                             f"dtype/size {dtype}/{size}")
        # Native FP8/BF16 retain their source representation. F16 is accepted
        # by the engine but expands to F32, so its two-byte file size is not a
        # safe cache budget.
        retained = size if dtype not in ("F16",) else elements * 4
        return ((int(match.group(1)), int(match.group(2)), retained),)
    match = _QWEN38_EXPERT_SCALE.fullmatch(name)
    if match:
        # The native loader normalizes all scales into one fixed per-layer
        # bank. They are deliberately excluded from per-slot accounting;
        # _qwen38_fixed_resident_inventory() accounts for that bank once.
        _qwen38_scale_bytes(name, size, config, dtype)
        return ()
    match = _QWEN38_FUSED_EXPERT.fullmatch(name)
    if not match:
        return ()
    experts = _required_int(config, "num_experts", "qwen38")
    hidden = _required_int(config, "hidden_size", "qwen38")
    intermediate = _required_int(config, "moe_intermediate_size", "qwen38")
    matrices = 2 if match.group(2) == "gate_up_proj" else 1
    elements = experts * matrices * hidden * intermediate
    if size not in (elements * 2, elements * 4):
        raise ValueError(f"qwen38: fused expert tensor {name!r} has unexpected size {size}")
    inferred = "BF16" if size == elements * 2 else "F32"
    dtype = inferred if dtype is None else dtype
    expected = {"BF16": elements * 2, "F16": elements * 2,
                "F32": elements * 4}.get(dtype)
    if expected != size:
        raise ValueError(f"qwen38: fused expert tensor {name!r} has unsupported "
                         f"dtype/size {dtype}/{size}")
    per_expert = (elements * 4 if dtype == "F16" else size) // experts
    layer = int(match.group(1))
    return tuple((layer, expert, per_expert) for expert in range(experts))


def _qwen38_scale_bytes(name, size, config, dtype=None):
    """Validate a Qwen3.8 FP8 scale sidecar and return its retained bytes.

    The source sidecar may be BF16 or F32, while the native engine always
    retains the decoded values as F32. This helper is shared by the expert
    inventory and fixed-resident inventory so validation and sizing cannot
    drift apart.
    """
    match = _QWEN38_EXPERT_SCALE.fullmatch(name)
    if match is None:
        return 0
    hidden = _required_int(config, "hidden_size", "qwen38")
    intermediate = _required_int(config, "moe_intermediate_size", "qwen38")
    projection = match.group(3)
    rows = intermediate if projection != "down_proj" else hidden
    cols = hidden if projection != "down_proj" else intermediate
    scale_count = math.ceil(rows / 128) * math.ceil(cols / 128)
    if dtype is None:
        if size == scale_count * 4:
            dtype = "F32"
        elif size == scale_count * 2:
            dtype = "BF16"
    source_bytes = {"BF16": 2, "F16": 2, "F32": 4}.get(dtype)
    if source_bytes is None or size != scale_count * source_bytes:
        raise ValueError(f"qwen38: expert scale {name!r} has unsupported "
                         f"dtype/size {dtype}/{size}")
    return scale_count * 4


def _qwen38_fixed_resident_inventory(name, size, config, dtype=None):
    """Return bytes for the native loader's fixed normalized scale bank.

    A sidecar contributes its normalized F32 footprint exactly once. For a
    native official checkpoint, summing all sidecars produces the complete
    bank (layers x experts x three projections), independent of cache slots.
    For a fallback layout the same charge is conservative: expanded loaders
    do not retain the bank, but reserving it cannot understate memory.
    """
    return _qwen38_scale_bytes(name, size, config, dtype)


_QWEN38_NATIVE_MATRIX_SUFFIXES = (
    "embed_tokens.weight",
    "input_mix_weight_down.weight",
    "input_mix_weight_up.weight",
    "block_inject_weight.weight",
    "mlp.gate.weight",
    "mlp.shared_expert.gate_proj.weight",
    "mlp.shared_expert.up_proj.weight",
    "mlp.shared_expert.down_proj.weight",
    "self_attn.q_proj.weight",
    "self_attn.k_proj.weight",
    "self_attn.v_proj.weight",
    "self_attn.o_proj.weight",
    "self_attn.indexer.index_qk_proj.weight",
    "linear_attn.in_proj_qkv.weight",
    "linear_attn.in_proj_z.weight",
    "linear_attn.in_proj_b.weight",
    "linear_attn.in_proj_a.weight",
    "linear_attn.out_proj.weight",
    "ple.key_proj.weight",
    "ple.value_proj.weight",
)


def _qwen38_trunk_inventory(name, size, _config, dtype=None):
    """int8 bytes the qwen38 engine's stage-1 trunk offload holds in VRAM for
    this tensor (docs/qwen38.md, "GPU"): the dense matmul matrices of the text
    model, quantized per row when the tier starts. Matrices under 1 MiB stay
    on the CPU (a round trip costs more than a tiny GEMV saves), and so do
    the PLE projections, the vision tower and everything that is not a matmul
    weight. embed_tokens stands in for the tied lm_head."""
    if name.startswith("mtp.") or name.startswith("model.visual.") or ".ple." in name:
        return 0
    text_tensor = (name == "lm_head.weight" or
                   name.startswith("model.language_model.") or
                   name.startswith("model."))
    if not text_tensor or not name.endswith(_QWEN38_NATIVE_MATRIX_SUFFIXES):
        return 0
    dtype = "BF16" if dtype is None else dtype
    element_bytes = {"BF16": 2, "F16": 2, "F32": 4}.get(dtype)
    if not element_bytes:
        return 0
    elements = size // element_bytes
    return elements if elements >= (1 << 20) else 0


def _qwen38_resident_inventory(name, size, _config, dtype=None):
    """Resident bytes for tensors the native text engine actually loads.

    The official checkpoints store non-quantized text tensors as BF16.  Major
    rank-two matrices stay in that two-byte representation; the comparatively
    small norms, gates and convolution vectors still expand through st_read_f32.
    """
    if isinstance(dtype, str) and dtype.startswith("GGUF_"):
        # a tools/gguf_import.py directory, GGUF names: the PLE table is read a
        # row at a time like the checkpoint's shards; every other tensor is
        # held as the file has it, F16 widened to f32 (q38_gg_weight)
        if name == "per_layer_token_embd.weight":
            return 0
        return size * 2 if dtype == "GGUF_F16" else size
    if _QWEN38_EXPERT_SCALE.fullmatch(name):
        # Expert scales belong to the fixed normalized bank, not dense
        # residency. The dedicated inventory hook accounts them once.
        return 0
    if name.startswith("mtp.") or name.startswith("model.visual."):
        return 0
    if ".ple.ple_embedding.ngram_embedding." in name and name.endswith(".weight"):
        return 0  # 51B-parameter PLE table stays pageable in st.h.
    if name.endswith((".ple.ple_embedding.layer_multipliers",
                      ".ple.ple_embedding.ngram_heads_vocab_sizes",
                      ".ple.ple_embedding.ngram_heads_offsets",
                      ".ple.ple_embedding.ngram_embedding.weight_scale")):
        # These few values are read into fixed fields in Model, not retained as
        # separately allocated source tensors.
        return 0
    text_tensor = (name == "lm_head.weight" or
                   name.startswith("model.language_model.") or
                   (name.startswith("model.") and
                    not name.startswith("model.visual.")))
    if not text_tensor:
        return 0
    # Direct registry tests predate dtype-bearing planner entries and use BF16
    # sizes; real scans always supply the safetensors dtype.
    dtype = "BF16" if dtype is None else dtype
    element_bytes = {"BF16": 2, "F16": 2, "F32": 4}.get(dtype)
    if not element_bytes:
        raise ValueError(f"qwen38: resident tensor {name!r} has unsupported dtype {dtype}")
    elements = size // element_bytes
    if elements * element_bytes != size:
        raise ValueError(f"qwen38: resident tensor {name!r} has invalid byte size {size}")
    if (name == "lm_head.weight" or
            name.endswith(_QWEN38_NATIVE_MATRIX_SUFFIXES)) and dtype == "BF16":
        return size
    return elements * 4


COMMON_CAP = FamilyCapabilities(False, False, False, True)

FAMILIES = (
    FamilyDescriptor(
        id="glm53",
        # "glm5_next" e' il tipo della radice, che e' il wrapper vision; un
        # export di solo testo dichiara "glm5_next_text" al primo livello.
        model_types=("glm5_next", "glm5_next_text"),
        display_name="GLM-5.3-Flash",
        # Niente ebits/io_bits/xbits: questo convertitore tiene i densi e
        # l'embedding in BF16 e la precisione la sceglie il motore a load time
        # (GLM53_BITS). Accettare quelle opzioni per poi ignorarle sarebbe la
        # versione silenziosa dello stesso guasto.
        converter="convert_glm53.py",
        converter_accepts=("group_size",),
        display_scale="321B",
        engine_artifact="glm53",
        engine_aliases=(),
        engine_group="glm53",
        internal_arch="glm53",
        build_target="glm53",
        process_names=("glm53",),
        default_model_id="glm-5.3-flash-colibri",
        cli_adapter="glm53",
        gateway_adapter="glm53",
        planner_id="glm53_hybrid",
        dense_load_ratio=_glm53_dense_in_ram,
        planner_geometry=_glm53_geometry,
        planner_unsupported_reason="",
        expert_inventory=_individual_expert_inventory(_GLM53_EXPERT),
        config_section="text_config",
        # implicit_cap 0, non 8: questo motore dimensiona la cache degli
        # esperti dalla RAM disponibile, quindi "nessuna scelta esplicita"
        # deve arrivargli come 0 e non come otto slot per layer.
        # L'interattivo era 1024, uguale al default non interattivo: l'unica
        # famiglia che ragiona a cui non era stato alzato. Su un modello che
        # riflette prima di rispondere quel tetto non e' una rete di sicurezza,
        # e' una ghigliottina che cade DENTRO al blocco di pensiero e chiude il
        # turno senza risposta (#1278). 16384 e' il valore che hanno gia' tutte
        # le famiglie con lo stesso contesto massimo di 1048576.
        limits=FamilyLimits(8192, 1048576, 1024, 16384, 16, 0, "GLM53_MAXT"),
        # tools=True: this family DOES render and parse tool calls. It used to
        # share COMMON_CAP, which says otherwise -- the flag is descriptive
        # (it only feeds the capability dict) so nothing broke, but a client
        # reading it programmatically was told the opposite of the truth.
        capabilities=FamilyCapabilities(True, False, False, True, image=True),
        has_gateway_adapter=True,
        has_cli_adapter=True,
        # Dal chat_template.jinja del checkpoint: nessun a capo, e <think>
        # subito dopo <|assistant|>, che e' quello che apre il ragionamento.
        tune_prompt_template="[gMASK]<sop><|user|>{prompt}<|assistant|><think>",
    ),
    FamilyDescriptor(
        id="glm",
        model_types=("glm_moe_dsa", "glm5_moe", "glm", "mistral_large4"),
        # Two model names, one family, and that is not a shortcut. Z.ai state
        # it on GLM-5.3's own card: "GLM-5.3 uses the same base model as
        # GLM-5.2 -- every gain comes from post-training." The checkpoints
        # agree. Diffing the two config.json leaves exactly one extra key
        # (moe_router_dtype) and the transformers_version that wrote the file:
        # same 78 layers, 256 experts, hidden 6144, moe_intermediate 2048, same
        # parameter count. There is nothing architectural to tell them apart,
        # so no rule over the configuration can name one and not the other, now
        # or later. #1326's approach for Qwen -- name a checkpoint by its
        # geometry -- cannot apply here, because the geometry is identical.
        #
        # Announcing a GLM-5.3 container as "GLM-5.2" was wrong in the one way
        # that matters: the engine ran the right weights and the banner named a
        # different model. Naming both is the honest statement of what this
        # family loads. If a future release ever adds a real discriminator,
        # split this then, on evidence.
        display_name="GLM-5.2/5.3",
        # Mistral-Large-4 (mistralai/Mistral-Large-4-1T-A52B): GLM-5.2's DSA attention without the
        # query LoRA, the same engine (colibri.c's attention_rows_ml4), its own chat format (the
        # gateway's mistral_large4 flavor) and name. The model_type tells them apart, at any size.
        display_variants=(
            DisplayVariant((("model_type", "glm_moe_dsa"),), "GLM-5.2/5.3", "744B"),
            DisplayVariant((("model_type", "glm5_moe"),), "GLM-5.2/5.3", "744B"),
            DisplayVariant((("model_type", "glm"),), "GLM-5.2/5.3", "744B"),
            DisplayVariant((("model_type", "mistral_large4"),), "Mistral-Large-4-1T-A52B", "1T",
                           model_id="mistral-large-4-colibri"),
        ),
        converter="convert_fp8_to_int4.py",
        converter_accepts=("ebits", "io_bits", "xbits", "group_size"),
        converter_mtp_pass=True,
        display_scale="744B",
        engine_artifact="colibri",
        split_dirs_env="COLI_MODEL_DIRS",
        engine_aliases=("glm",),
        engine_group="colibri-core",
        internal_arch="glm",
        build_target="colibri",
        process_names=("colibri", "glm"),
        default_model_id="glm-5.2-colibri",
        cli_adapter="glm",
        gateway_adapter="glm",
        planner_id="glm_mla",
        planner_geometry=_glm_geometry,
        planner_unsupported_reason="",
        expert_inventory=_individual_expert_inventory(_GLM_EXPERT),
        config_section="root",
        limits=FamilyLimits(4096, 1048576, 1024, 16384, 16, 0, "CTX"),
        # image: Mistral-Large-4's pictures (expand_ml4_images); the engine says whether it loaded
        # the tower (CAPS vision=), GLM-5.2 has none
        capabilities=FamilyCapabilities(True, True, False, True, image=True,
                                        logprobs_echo=True, submit_gbytes=True),
        has_gateway_adapter=True,
        has_cli_adapter=True,
        tune_prompt_template="[gMASK]<sop><|user|>{prompt}<|assistant|><think></think>",
    ),
    FamilyDescriptor(
        id="inkling",
        model_types=("inkling_mm_model", "inkling"),
        display_name="Inkling",
        display_scale="975B",
        engine_artifact="inkling",
        engine_aliases=(),
        engine_group="inkling",
        internal_arch="inkling",
        build_target="inkling",
        process_names=("inkling",),
        default_model_id="inkling-colibri",
        cli_adapter="inkling",
        gateway_adapter="inkling",
        planner_id="inkling_hybrid",
        planner_geometry=_inkling_geometry,
        planner_unsupported_reason="",
        expert_inventory=_inkling_expert_inventory,
        config_section="text_config",
        # L'interattivo era 1024, uguale al default non interattivo: l'unica
        # famiglia che ragiona a cui non era stato alzato. Su un modello che
        # riflette prima di rispondere quel tetto non e' una rete di sicurezza,
        # e' una ghigliottina che cade DENTRO al blocco di pensiero e chiude il
        # turno senza risposta (#1278). 16384 e' il valore che hanno gia' tutte
        # le famiglie con lo stesso contesto massimo di 1048576.
        limits=FamilyLimits(8192, 1048576, 1024, 16384, 16, 8, "CTX_MAX"),
        capabilities=FamilyCapabilities(False, False, True, True),
        has_gateway_adapter=True,
        tune_prompt_template="<|user|>{prompt}<|assistant|>",
    ),
    FamilyDescriptor(
        id="kimi",
        # "kimi_linear" is Moonshot's model_type for the text model itself
        # (the real checkpoint's text_config carries it; the root "kimi_k3"
        # belongs to the vision wrapper). A text-only export -- the tiny
        # fixture included -- is therefore kimi_linear at top level. Kimi
        # K3.1 (moonshotai/Kimi-K3.1-Pro) is the same text model with a DSA
        # indexer on its MLA layers; its wrapper's root model_type is kimi_k31.
        model_types=("kimi_k3", "kimi_linear", "kimi_k31"),
        display_name="Kimi K3",
        display_scale="2.8T",
        engine_artifact="kimi_k3",
        split_dirs_env="K3_DIRS",
        engine_aliases=(),
        engine_group="kimi_k3",
        internal_arch="kimi_k3",
        build_target="kimi_k3",
        process_names=("kimi_k3",),
        default_model_id="kimi-k3-colibri",
        cli_adapter="kimi",
        gateway_adapter="kimi",
        planner_id="kimi_hybrid",
        planner_geometry=_kimi_geometry,
        planner_unsupported_reason="",
        expert_inventory=_individual_expert_inventory(_KIMI_EXPERT),
        config_section="text_config",
        # L'interattivo era 1024, uguale al default non interattivo: l'unica
        # famiglia che ragiona a cui non era stato alzato. Su un modello che
        # riflette prima di rispondere quel tetto non e' una rete di sicurezza,
        # e' una ghigliottina che cade DENTRO al blocco di pensiero e chiude il
        # turno senza risposta (#1278). 16384 e' il valore che hanno gia' tutte
        # le famiglie con lo stesso contesto massimo di 1048576.
        limits=FamilyLimits(8192, 1048576, 1024, 16384, 16, 8, "K3_MAXT"),
        # tools=True: this family DOES render and parse tool calls. It used to
        # share COMMON_CAP, which says otherwise -- the flag is descriptive
        # (it only feeds the capability dict) so nothing broke, but a client
        # reading it programmatically was told the opposite of the truth.
        # image=True: Kimi K3.1's pictures (expand_kimi_images, kimi_k3.c's tower, k3_vision.h);
        # whether the checkpoint served has the tower is the engine's CAPS vision=1.
        capabilities=FamilyCapabilities(True, False, False, True, image=True),
        has_gateway_adapter=True,
        tune_prompt_template="K3CHAT1\nM user {prompt_len}\n{prompt}G 0\n\n",
    ),
    FamilyDescriptor(
        id="olmoe",
        model_types=("olmoe",),
        display_name="OLMoE",
        display_scale="7B",
        engine_artifact="olmoe",
        engine_aliases=(),
        engine_group="olmoe",
        internal_arch="olmoe",
        build_target="olmoe",
        process_names=("olmoe",),
        default_model_id="olmoe-colibri",
        cli_adapter="olmoe",
        gateway_adapter="olmoe",
        planner_id="olmoe_gqa",
        planner_geometry=_olmoe_geometry,
        planner_unsupported_reason="",
        # A CUDA build runs every layer and every routed expert as one chain on
        # the card with COLI_CUDA=1 (olmoe_cuda_chain.h: the whole model in VRAM,
        # or the CPU when it does not fit). Since #1830 a VK=1 build can put it on
        # a Vulkan device too (COLI_VULKAN=1), opt-in and outside the planner.
        supports_accelerator=True,
        expert_inventory=_individual_expert_inventory(_GLM_EXPERT),
        # coli convert routes to convert_olmoe_merged.py (d4d11ef dispatch);
        # the converter takes no precision flags (--ebits / --group-size etc.).
        converter="convert_olmoe_merged.py",
        converter_accepts=(),
        config_section="root",
        # implicit_cap 0, not 8: the engine sizes its expert cache from the RAM
        # budget once the dense weights are resident (#1443), so "nobody chose a
        # number" has to arrive as the sentinel. Eight slots per layer knows
        # nothing about the model or the machine, and on OLMoE it is five times
        # slower than the cache the same machine could hold: measured on a
        # 1204-token prefill, cap 8 gives 22.8% expert hit rate and 0.045 tok/s,
        # cap 64 gives 99.4% and 0.215 tok/s.
        limits=FamilyLimits(4096, 4096, 1024, 1024, 16, 0, "CTX"),
        capabilities=FamilyCapabilities(False, False, False, False),
        has_gateway_adapter=True,
        has_cli_adapter=True,
        tune_prompt_template="<|user|>\n{prompt}\n<|assistant|>\n",
    ),
    FamilyDescriptor(
        id="qwen36",
        # qwen3_5 / qwen3_5_text: the dense checkpoints of the same architecture
        # (Qwen3.8-27B, #1757). The engine loads their MLP as an ungated shared
        # expert and routes nothing.
        # qwen3_moe: Qwen3-Coder-30B-A3B and its REAP prunes, every layer attention,
        # no shared expert (tools/convert_qwen36.py writes their container).
        # qwen3: the dense Qwen3 (0.6B to 32B), qwen3_moe's layers with one MLP each.
        # flint: Flint (RecursiveSI/flint), qwen3_moe's layers with a sink per head,
        # sliding-window layers, dense layers in front and sigmoid routing.
        # muse_spark: Muse Spark Open (its GGUFs, tools/gguf_import.py), Flint's window and
        # layers without RoPE, residual gates and the experts at their own width.
        # lfm3: LFM3 (LiquidAI/LFM3-VL, its text model; lfm3_vl the checkpoint's own type),
        # dense, short gated convolutions beside attention layers.
        model_types=("qwen3_5_moe", "qwen3_5_moe_text", "qwen3_5", "qwen3_5_text", "qwen3_moe", "qwen3", "flint",
                     "muse_spark", "lfm3", "lfm3_vl"),
        display_name="Qwen3.6-35B-A3B",
        display_scale="35B",
        # Both checkpoints declare qwen3_5_moe_text. Keyed on the three
        # numbers that differ by an order of magnitude, so a config with
        # any of them off names itself rather than one of these.
        display_variants=(
            DisplayVariant((("num_hidden_layers", 40), ("num_experts", 256),
                            ("hidden_size", 2048)),
                           "Qwen3.6-35B-A3B", "35B"),
            DisplayVariant((("num_hidden_layers", 92), ("num_experts", 512),
                            ("hidden_size", 8192)),
                           "Qwen3.8-2.4T-A95B", "2.4T"),
            DisplayVariant((("num_hidden_layers", 64), ("hidden_size", 5120),
                            ("intermediate_size", 17408)),
                           "Qwen3.8-27B", "27B", model_id="qwen3.8-27b-colibri"),
            DisplayVariant((("num_hidden_layers", 48),
                            ("num_experts", 128), ("hidden_size", 2048)),
                           "Qwen3-Coder-30B-A3B", "30B", model_id="qwen3-coder-30b-a3b-colibri"),
            DisplayVariant((("num_hidden_layers", 48),
                            ("num_experts", 103), ("hidden_size", 2048)),
                           "Qwen3-Coder-REAP-25B-A3B", "25B",
                           model_id="qwen3-coder-reap-25b-a3b-colibri"),
            DisplayVariant((("num_hidden_layers", 49),
                            ("num_experts", 256), ("hidden_size", 2048)),
                           "Flint", "40B", model_id="flint-colibri"),
            DisplayVariant((("num_hidden_layers", 62),
                            ("num_experts", 256), ("hidden_size", 8192)),
                           "Muse-Spark-Open-816B-A42B", "816B", model_id="muse-spark-open-colibri"),
            DisplayVariant((("num_hidden_layers", 24), ("hidden_size", 2048),
                            ("intermediate_size", 7680)),
                           "LFM3-VL-2B", "2B", model_id="lfm3-vl-2b-colibri"),
        ),
        engine_artifact="qwen36",
        engine_aliases=(),
        engine_group="qwen36",
        internal_arch="qwen36",
        build_target="qwen36",
        process_names=("qwen36",),
        default_model_id="qwen3.6-colibri",
        cli_adapter="qwen36",
        gateway_adapter="qwen36",
        planner_id="qwen36_hybrid",
        planner_geometry=_qwen36_geometry,
        planner_unsupported_reason="",
        expert_inventory=_individual_expert_inventory(_GLM_EXPERT),
        config_section="text_config",
        limits=FamilyLimits(8192, 262144, 1024, 8192, 16, 8, "Q36_MAXT"),
        capabilities=FamilyCapabilities(True, False, False, True, image=True,
                                        logprobs_echo=True),
        has_gateway_adapter=True,
        # coli run stays unwired on purpose: cmd_run dispatches per arch after
        # this gate, and without a qwen36 branch the engine would inherit GLM's
        # prompt template -- a wrong template does not fail loudly, it degrades
        # the answer. False gives the user "use coli chat or coli serve", which
        # is true and actionable; chat/serve/web all work through the gateway.
        has_cli_adapter=False,
        tune_prompt_template=(
            "<|im_start|>user\n{prompt}<|im_end|>\n<|im_start|>assistant\n<think>\n"),
    ),
    FamilyDescriptor(
        id="qwen38",
        model_types=("qwen4_exp", "qwen4_exp_text"),
        display_name="Qwen3.8-Flash-Next",
        display_scale="176B",
        engine_artifact="qwen38",
        split_dirs_env="Q38_DIRS",
        engine_aliases=(),
        engine_group="qwen38",
        internal_arch="qwen38",
        build_target="qwen38",
        process_names=("qwen38",),
        default_model_id="qwen3.8-flash-next-colibri",
        cli_adapter="qwen38",
        gateway_adapter="qwen38",
        planner_id="qwen38_hybrid",
        planner_geometry=_qwen38_geometry,
        planner_unsupported_reason="",
        expert_inventory=_qwen38_expert_inventory,
        resident_inventory=_qwen38_resident_inventory,
        fixed_resident_inventory=_qwen38_fixed_resident_inventory,
        config_section="text_config",
        limits=FamilyLimits(8192, 262144, 1024, 8192, 16, 1, "Q38_MAXT"),
        capabilities=FamilyCapabilities(True, False, False, True, image=True),
        has_gateway_adapter=True,
        # Like Qwen3.6, direct `coli run` is intentionally not exposed until
        # an engine-specific CLI prompt path exists; chat/serve use the gateway.
        has_cli_adapter=False,
        tune_prompt_template=(
            "<|im_start|>system\nReasoning effort is set to xhigh. Please think carefully "
            "through the task, validate key assumptions, consider plausible alternatives, "
            "and prioritize correctness, consistency, and clarity in the final answer."
            "<|im_end|>\n<|im_start|>user\n{prompt}<|im_end|>\n"
            "<|im_start|>assistant\n<think>\n"),
        # CUDA VRAM expert tier (qwen36_tier.c, fp8 streaming mode): hot
        # routed experts get VRAM copies above the RAM LRU, and the dense
        # trunk goes first, as int8 residents (docs/qwen38.md, "GPU").
        supports_accelerator=True,
        trunk_inventory=_qwen38_trunk_inventory,
    ),
    FamilyDescriptor(
        id="deepseek_v4",
        model_types=("deepseek_v4",),
        display_name="DeepSeek V4 Flash",
        display_scale="284B",
        # deepseek-ai/DeepSeek-V4-Flash-0731 config.json: 43 layer, 256
        # esperti, top-k 6. Il REAP a 150B (#1310) ne ha 132 sugli stessi 43
        # layer: e' quello che fa scattare la geometria misurata nel banner.
        reference_experts=256,
        engine_artifact="deepseek_v4",
        split_dirs_env="COLI_MODEL_DIRS",
        engine_aliases=(),
        engine_group="deepseek_v4",
        internal_arch="deepseek_v4",
        build_target="deepseek-v4",
        process_names=("deepseek_v4",),
        default_model_id="deepseek-v4-colibri",
        cli_adapter="deepseek_v4",
        gateway_adapter="deepseek_v4",
        planner_id="deepseek_v4",
        planner_geometry=_dsv4_geometry,
        planner_unsupported_reason="",
        expert_inventory=_individual_expert_inventory(_V4_EXPERT),
        config_section="root",
        limits=FamilyLimits(4096, 1048576, 1024, 16384, 16, 8, "CTX"),
        capabilities=FamilyCapabilities(True, False, False, True),
        has_gateway_adapter=True,
        has_cli_adapter=True,
    ),
    FamilyDescriptor(
        id="deepseek_v41",
        model_types=("deepseek_v41", "deepseek_v41_text"),
        display_name="DeepSeek V4.1 Flash",
        display_scale="552B",
        # deepseek-ai/DeepSeek-V4.1-Flash: 40 layers, 384 experts, top-6, plus
        # two 384M-row engram tables that never enter RAM.
        reference_experts=384,
        engine_artifact="deepseek_v41",
        split_dirs_env="COLI_MODEL_DIRS",
        engine_aliases=(),
        engine_group="deepseek_v41",
        internal_arch="deepseek_v41",
        build_target="deepseek_v41",
        process_names=("deepseek_v41",),
        default_model_id="deepseek-v4.1-flash-colibri",
        cli_adapter="deepseek_v41",
        gateway_adapter="deepseek_v41",
        planner_id="deepseek_v41",
        planner_geometry=_dsv41_geometry,
        planner_unsupported_reason="",
        # A CUDA build holds the routed experts in VRAM on the shared tier
        # (cu_tier.h, COLI_CUDA=1); a build with Vulkan too runs on Vulkan unless
        # COLI_VULKAN=0. Before that the engine linked no CUDA/Metal path and this
        # was False: the planner must not offer a VRAM tier it cannot execute
        # (resource_plan.py's gate, "a CPU-only engine has no VRAM tier").
        # tests/test_registry_engine_agreement.py holds it to the build rule.
        supports_accelerator=True,
        expert_inventory=_dsv41_expert_inventory,
        resident_inventory=_dsv41_resident_inventory,
        config_section="text_config",
        limits=FamilyLimits(4096, 1048576, 1024, 16384, 16, 8, "CTX"),
        # tools yes (DSML, see v41_dsml.py), grammars no: the engine reads the six-field
        # SUBMIT header and has no constrained decoder, so a grammar has to be refused
        # at the gateway rather than desync the wire.
        capabilities=FamilyCapabilities(True, False, False, True, image=True),
        has_gateway_adapter=True,
        # coli run stays unwired, for the reason qwen36 gives above and one more:
        # cmd_run dispatches per arch after this gate, and with no deepseek_v41
        # branch of its own the launcher would fall through to GLM's binary and
        # GLM's prompt template. The engine speaks the SERVE protocol and nothing
        # else, so a one-shot has nowhere to go but the gateway -- which is what
        # coli chat, coli serve and coli web already use.
        has_cli_adapter=False,
    ),
    FamilyDescriptor(
        id="mimo",
        model_types=("mimo_v2",),
        display_name="MiMo-V2.6 Flash",
        display_scale="309B",
        # XiaomiMiMo/MiMo-V2.6-{Flash,Pro}: same architecture, two sizes.
        reference_experts=256,
        display_variants=(
            DisplayVariant((("hidden_size", 4096), ("num_hidden_layers", 48),
                            ("n_routed_experts", 256)),
                           "MiMo-V2.6 Flash", "309B"),
            DisplayVariant((("hidden_size", 6144), ("num_hidden_layers", 70),
                            ("n_routed_experts", 384)),
                           "MiMo-V2.6 Pro", "1.02T", model_id="mimo-v2.6-pro"),
        ),
        engine_artifact="mimo",
        split_dirs_env="MIMO_DIRS",
        engine_aliases=(),
        engine_group="mimo",
        internal_arch="mimo",
        build_target="mimo",
        process_names=("mimo",),
        default_model_id="mimo-v2.6-flash",
        cli_adapter="mimo",
        gateway_adapter="mimo",
        planner_id="mimo",
        planner_geometry=_mimo_geometry,
        planner_unsupported_reason="",
        # No CUDA expert tier to plan: MIMO_CUDA places native dense matrices
        # under its own byte budget and retains their host copies. Its Vulkan path
        # (#1830's dense matrices, and the routed experts on the shared Vulkan tier,
        # vk_tier.c) is opt-in and outside the planner (see deepseek_v41 above for
        # why the planner must not offer a VRAM tier the engine cannot use).
        supports_accelerator=False,
        expert_inventory=_mimo_expert_inventory,
        resident_inventory=_mimo_resident_inventory,
        config_section="root",
        # top-8 routing: the engine raises any smaller cache to one routing step
        limits=FamilyLimits(8192, 1048576, 1024, 16384, 16, 16, "CTX"),
        # tools (the XML call form, parse_mimo_tool_calls), thinking (on by default,
        # as the template has it); no grammars, no audio in or out
        capabilities=FamilyCapabilities(True, False, False, True, image=True,
                                        logprobs_echo=True, submit_gbytes=True),
        has_gateway_adapter=True,
        # the engine is driven through the gateway (SERVE); coli run has no mimo
        # branch and would fall through to GLM's binary, as for deepseek_v41
        has_cli_adapter=False,
        # the gateway's cue with thinking on (render_chat_mimo): the template's
        # ChatML with no newline after <|im_end|>, and the <think> the model writes
        tune_prompt_template="<|im_start|>user\n{prompt}<|im_end|><|im_start|>assistant\n<think>",
    ),
    FamilyDescriptor(
        id="qwen_image",
        # A diffusers pipeline has no config.json at its root: the family is
        # read from model_index.json's _class_name (see resolve_model), which
        # is what this entry holds, normalized like every model_type.
        model_types=("qwenimage21pipeline",),
        display_name="Qwen-Image-2.1",
        display_scale="",
        engine_artifact="qwenimage",
        engine_aliases=(),
        engine_group="qwenimage",
        internal_arch="qwenimage",
        build_target="qwenimage",
        process_names=("qwenimage",),
        default_model_id="qwen-image-2.1-colibri",
        cli_adapter="qwen_image",
        gateway_adapter="qwen_image",
        planner_id="qwen_image",
        planner_geometry=None,
        planner_unsupported_reason=(
            "an image model has no KV cache and no experts; coli plan sizes its "
            "text encoder, DiT and VAE instead (image_engine.plan_image_model)"),
        expert_inventory=lambda _name, _size, _config, _dtype=None: (),
        config_section="root",
        # One image at a time, and no context or output-token budget: the
        # limits exist because every descriptor has them. No context variable
        # either (empty): the launcher refuses --ctx for this modality rather
        # than inventing a knob the engine does not read.
        limits=FamilyLimits(1, 1, 1, 1, 1, 0, ""),
        capabilities=FamilyCapabilities(False, False, False, False),
        has_gateway_adapter=True,
        has_cli_adapter=True,
        supports_accelerator=False,
        modality="image",
        tokenizer_file="processor/tokenizer.json",
    ),
    FamilyDescriptor(
        id="laya",
        # A Laya checkpoint has no config.json at its root: resolve_model reads
        # rl_agent_config.json and the encoder's own config.json, and names it
        # laya_<encoder model_type>. The English and typed-decisions checkpoints
        # are ModernBERT-large; laya-multilingual is mmBERT-base, also model_type
        # modernbert, and is told apart by its geometry.
        model_types=("laya_modernbert",),
        display_name="Laya",
        display_scale="421M",
        display_variants=(
            DisplayVariant((("hidden_size", 1024), ("num_hidden_layers", 28)), "Laya", "421M"),
            DisplayVariant((("hidden_size", 768), ("num_hidden_layers", 22)),
                           "Laya multilingual", "322M", model_id="laya-multilingual"),
        ),
        engine_artifact="laya",
        engine_aliases=(),
        engine_group="laya",
        internal_arch="laya",
        build_target="laya",
        process_names=("laya",),
        default_model_id="laya",
        cli_adapter="laya",
        gateway_adapter="laya",
        planner_id="laya",
        planner_geometry=None,
        planner_unsupported_reason=(
            "a decision model has no KV cache and no experts: it keeps its weights "
            "resident (about 1.7 GB in f32 for the 421M checkpoint) and reads at "
            "most max_len tokens per question"),
        expert_inventory=lambda _name, _size, _config, _dtype=None: (),
        config_section="root",
        # max_len 512 (the English checkpoint) by default; the multilingual
        # encoder reads up to 8192. No generation, so the output budgets are the
        # placeholders every descriptor carries, and no context variable: the
        # engine's own COLI_LAYA_MAX_LEN overrides the checkpoint's max_len.
        limits=FamilyLimits(512, 8192, 1, 1, 1, 0, ""),
        capabilities=FamilyCapabilities(False, False, False, False, decision=True),
        has_gateway_adapter=True,
        # one-shot `coli run` has nothing to run: a decision needs questions,
        # which come over POST /v1/systemone from `coli serve` / `coli web`
        has_cli_adapter=False,
        # COLI_CUDA=1 (--gpu): the forward on a CUDA device (decide_cuda.h); no tier to size
        supports_accelerator=True,
        modality="decision",
        tokenizer_file="tokenizer/tokenizer.json",
        checkpoint_files=("tokenizer/tokenizer_config.json", "encoder/config.json"),
    ),
    FamilyDescriptor(
        id="gliner_decide",
        # A GLiNER2 checkpoint's config.json says model_type "extractor" for
        # every architecture and encoder: resolve_model reads its architecture
        # and the encoder's own config (encoder_config/config.json) and names it
        # gliner2_<architecture>_<encoder model_type>. The engine runs the
        # classification head of the span architecture on a DeBERTa-v2/v3
        # encoder; GLiNER2.5-Decide is DeBERTa-v3-large (24 layers x 1024).
        model_types=("gliner2_span_deberta-v2",),
        display_name="GLiNER2.5-Decide",
        display_scale="340M",
        display_variants=(
            DisplayVariant((("hidden_size", 1024), ("num_hidden_layers", 24)),
                           "GLiNER2.5-Decide", "340M"),
        ),
        engine_artifact="gliner_decide",
        engine_aliases=(),
        engine_group="gliner_decide",
        internal_arch="gliner_decide",
        build_target="gliner_decide",
        process_names=("gliner_decide",),
        default_model_id="gliner2.5-decide",
        cli_adapter="gliner_decide",
        gateway_adapter="gliner_decide",
        planner_id="gliner_decide",
        planner_geometry=None,
        planner_unsupported_reason=(
            "a decision model has no KV cache and no experts: it keeps its encoder and "
            "classification head resident in f32 and reads every question of a request and "
            "the state in one sequence of at most COLI_GLINER_MAX_LEN tokens"),
        expert_inventory=lambda _name, _size, _config, _dtype=None: (),
        config_section="root",
        # One sequence per request, cut at 4096 tokens by default
        # (COLI_GLINER_MAX_LEN); the encoder's relative positions set no
        # ceiling of their own. No generation, so the output budgets are the
        # placeholders every descriptor carries, and no context variable.
        limits=FamilyLimits(4096, 4096, 1, 1, 1, 0, ""),
        capabilities=FamilyCapabilities(False, False, False, False, decision=True),
        has_gateway_adapter=True,
        has_cli_adapter=False,
        # COLI_CUDA=1 (--gpu): the forward on a CUDA device (decide_cuda.h); no tier to size
        supports_accelerator=True,
        modality="decision",
        tokenizer_file="tokenizer.json",
        checkpoint_files=("config.json", "encoder_config/config.json"),
    ),
)


def _build_registry(families):
    by_id = {}
    by_type = {}
    identities = set()
    for family in families:
        if not re.fullmatch(r"[a-z0-9_]+", family.id) or family.id in by_id:
            raise RegistryError(f"invalid or duplicate family id: {family.id!r}")
        if (not family.model_types or
                (not callable(family.planner_geometry) and
                  not family.planner_unsupported_reason) or
                 not callable(family.expert_inventory) or
                (family.resident_inventory is not None and
                 not callable(family.resident_inventory)) or
                (family.fixed_resident_inventory is not None and
                 not callable(family.fixed_resident_inventory)) or
                not isinstance(family.supports_accelerator, bool) or
                not isinstance(family.has_gateway_adapter, bool) or
                not isinstance(family.has_cli_adapter, bool) or
                not isinstance(family.tune_prompt_template, str) or
                "{prompt}" not in family.tune_prompt_template or
                family.modality not in ("text", "image", "decision") or
                family.capabilities.decision != (family.modality == "decision") or
                not isinstance(family.tokenizer_file, str) or not family.tokenizer_file or
                not isinstance(family.checkpoint_files, tuple) or
                any(not isinstance(name, str) or not name for name in family.checkpoint_files)):
            raise RegistryError(f"incomplete family descriptor: {family.id}")
        try:
            family.tune_prompt_template.format(prompt="test", prompt_len=4)
        except (AttributeError, IndexError, KeyError, TypeError, ValueError) as error:
            raise RegistryError(f"invalid tune prompt template: {family.id}") from error
        for variant in family.display_variants:
            if (not isinstance(variant, DisplayVariant) or not variant.geometry or
                    not isinstance(variant.display_name, str) or not variant.display_name or
                    not isinstance(variant.display_scale, str) or
                    any(not isinstance(key, str) or not key or isinstance(value, bool) or
                        not ((isinstance(value, int) and value >= 1) or
                             (key == "model_type" and isinstance(value, str) and value))
                        for key, value in variant.geometry)):
                raise RegistryError(f"invalid display variant: {family.id}")
        # The static display_name is what the READMEs are held to mention, so
        # it must be a name some checkpoint actually shows -- a family whose
        # variants all say something else would document a name no banner
        # prints.
        if family.display_variants and family.display_name not in {
                variant.display_name for variant in family.display_variants}:
            raise RegistryError(f"display_name is not one of its variants: {family.id}")
        identity = (family.engine_artifact, family.internal_arch)
        if identity in identities:
            raise RegistryError(f"duplicate engine identity: {identity}")
        identities.add(identity)
        by_id[family.id] = family
        for model_type in family.model_types:
            normalized = _normalize_model_type(model_type)
            if normalized in by_type:
                raise RegistryError(f"duplicate model_type alias: {normalized}")
            by_type[normalized] = family
        if (family.limits.default_context < 1 or family.limits.max_context < family.limits.default_context or
                family.limits.default_max_output < 1 or family.limits.interactive_max_output < 1 or
                family.limits.max_kv_slots < 1 or family.limits.implicit_cap < 0):
            raise RegistryError(f"invalid limits for family: {family.id}")
    return by_id, by_type


def _normalize_model_type(model_type):
    if not isinstance(model_type, str) or not model_type.strip():
        raise FamilyConfigError("config.json has no non-empty string model_type")
    return model_type.strip().lower()


_BY_ID, _BY_TYPE = _build_registry(FAMILIES)


def all_families():
    return FAMILIES


def family_ids():
    return tuple(family.id for family in FAMILIES)


def family_by_id(family_id):
    try:
        return _BY_ID[family_id]
    except KeyError as error:
        raise UnknownFamilyError(f"unknown model family: {family_id}") from error


def family_for_config(config):
    if not isinstance(config, dict):
        raise FamilyConfigError("config.json is not a JSON object")
    if "model_type" not in config and isinstance(config.get("_class_name"), str):
        # A diffusers model_index.json: the pipeline class is its model type.
        return family_for_index(config)
    model_type = _normalize_model_type(config.get("model_type"))
    try:
        return _BY_TYPE[model_type]
    except KeyError as error:
        raise UnknownFamilyError(f"unsupported model_type: {model_type}") from error


def family_for_index(index):
    """The family of a diffusers pipeline, from its model_index.json."""
    if not isinstance(index, dict):
        raise FamilyConfigError(f"{MODEL_INDEX} is not a JSON object")
    name = index.get("_class_name")
    if not isinstance(name, str) or not name.strip():
        raise FamilyConfigError(f"{MODEL_INDEX} has no non-empty string _class_name")
    try:
        family = _BY_TYPE[_normalize_model_type(name)]
    except KeyError as error:
        raise UnknownFamilyError(f"unsupported diffusers pipeline: {name}") from error
    if family.modality != "image":
        raise UnknownFamilyError(f"unsupported diffusers pipeline: {name}")
    return family


def tuning_replay_prompt(family, prompt):
    if not isinstance(prompt, str):
        raise ValueError("tuning prompt must be a string")
    return family.tune_prompt_template.format(prompt=prompt, prompt_len=len(prompt))


MODEL_INDEX = "model_index.json"
# A Laya checkpoint (and anything trained with its code) carries this instead of
# a root config.json; its encoder's config.json sits in encoder/.
DECISION_CONFIG = "rl_agent_config.json"


def _resolve_decision_checkpoint(model):
    """A Laya-style decision checkpoint: rl_agent_config.json at the root, the
    encoder's config.json under encoder/. The family is keyed on the encoder,
    laya_<model_type>, and the encoder config is the family config (its geometry
    names the variant)."""
    def load(path, what):
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except OSError as error:
            raise FamilyConfigError(f"cannot read {what}: {model}") from error
        except json.JSONDecodeError as error:
            raise FamilyConfigError(f"invalid {what}: {error}") from error
        if not isinstance(value, dict):
            raise FamilyConfigError(f"{what} is not a JSON object")
        return value
    config = load(model / DECISION_CONFIG, DECISION_CONFIG)
    encoder = load(model / "encoder" / "config.json", "encoder/config.json")
    model_type = "laya_" + _normalize_model_type(encoder.get("model_type"))
    try:
        family = _BY_TYPE[model_type]
    except KeyError as error:
        raise UnknownFamilyError(f"unsupported decision checkpoint: an "
                                 f"{encoder.get('model_type')} encoder") from error
    if family.modality != "decision":
        raise UnknownFamilyError(f"unsupported decision checkpoint: {model_type}")
    return ResolvedFamily(family, model_type, config, encoder, str(model))


# GLiNER2's config.json says model_type "extractor" whatever the architecture
# and the encoder ("gliner2" in fastino's repository since its transformers form,
# the same weights); the encoder's own config sits in encoder_config/.
GLINER2_MODEL_TYPES = ("extractor", "gliner2")
GLINER2_ENCODER_CONFIG = "encoder_config/config.json"


def _resolve_gliner2_checkpoint(model, config):
    """A GLiNER2 checkpoint (gliner2's ExtractorConfig): the family is keyed on
    the architecture and the encoder, gliner2_<architecture>_<encoder
    model_type>, and the encoder config is the family config (its geometry
    names the variant). A checkpoint without an architecture is "span", as
    gliner2's AutoExtractor reads it."""
    path = model / GLINER2_ENCODER_CONFIG
    try:
        encoder = json.loads(path.read_text(encoding="utf-8"))
    except OSError as error:
        raise FamilyConfigError(f"cannot read {GLINER2_ENCODER_CONFIG}: {model}") from error
    except json.JSONDecodeError as error:
        raise FamilyConfigError(f"invalid {GLINER2_ENCODER_CONFIG}: {error}") from error
    if not isinstance(encoder, dict):
        raise FamilyConfigError(f"{GLINER2_ENCODER_CONFIG} is not a JSON object")
    architecture = config.get("architecture") or "span"
    if not isinstance(architecture, str):
        raise FamilyConfigError("config.json: architecture is not a string")
    model_type = (f"gliner2_{_normalize_model_type(architecture)}_"
                  f"{_normalize_model_type(encoder.get('model_type'))}")
    try:
        family = _BY_TYPE[model_type]
    except KeyError as error:
        raise UnknownFamilyError(f"unsupported GLiNER2 checkpoint: the {architecture} architecture "
                                 f"on an {encoder.get('model_type')} encoder") from error
    return ResolvedFamily(family, model_type, config, encoder, str(model))


def resolve_model(model_dir):
    model = Path(model_dir).expanduser().resolve()
    path = model / "config.json"
    if not path.is_file() and (model / DECISION_CONFIG).is_file():
        return _resolve_decision_checkpoint(model)
    if not path.is_file() and (model / MODEL_INDEX).is_file():
        # A diffusers pipeline (Qwen-Image): the root carries model_index.json
        # and each component keeps its own config.json in its own directory.
        # config.json wins when both exist, so a text checkpoint that happens
        # to ship an index is never read as an image model.
        try:
            index = json.loads((model / MODEL_INDEX).read_text(encoding="utf-8"))
        except OSError as error:
            raise FamilyConfigError(f"cannot read {MODEL_INDEX}: {model}") from error
        except json.JSONDecodeError as error:
            raise FamilyConfigError(f"invalid {MODEL_INDEX}: {error}") from error
        family = family_for_index(index)
        return ResolvedFamily(family, _normalize_model_type(index["_class_name"]),
                              index, index, str(model))
    try:
        config = json.loads(path.read_text(encoding="utf-8"))
    except OSError as error:
        raise FamilyConfigError(
            f"cannot read config.json: {model}\n"
            "  coli picks the engine from config.json, so nothing runs without it. Copy the\n"
            "  checkpoint's config.json (with tokenizer.json and model.safetensors.index.json)\n"
            "  from the model repo next to the shards. An image model (a diffusers pipeline)\n"
            "  carries model_index.json instead.") from error
    except json.JSONDecodeError as error:
        raise FamilyConfigError(f"invalid config.json: {error}") from error
    if isinstance(config, dict) and config.get("model_type") in GLINER2_MODEL_TYPES:
        return _resolve_gliner2_checkpoint(model, config)
    family = family_for_config(config)
    family_config = config
    if family.config_section == "text_config":
        family_config = config.get("text_config", config)
        if not isinstance(family_config, dict):
            raise FamilyConfigError(f"{family.id}: text_config is not an object")
    head = ""
    for candidate in DECISION_HEADS:
        present = [name for name in candidate.files if (model / name).is_file()]
        if candidate.family == family.id and present:
            if len(present) != len(candidate.files):
                raise FamilyConfigError(f"{model}: {present[0]} without "
                                        f"{', '.join(n for n in candidate.files if n not in present)}: "
                                        f"a {candidate.display_name} decision head needs all of "
                                        f"{', '.join(candidate.files)}")
            head = candidate.id
    return ResolvedFamily(family, _normalize_model_type(config.get("model_type")),
                          config, family_config, str(model), head)


def _gguf_name(resolved):
    """(name, size label) of a model folder tools/gguf_import.py wrote: the GGUF's own
    general.name, e.g. ("Qwen3-0.6B", "0.6B"); ("", "") for anything else."""
    gg = (getattr(resolved, "config", None) or {}).get("colibri_gguf")
    if not isinstance(gg, dict) or not isinstance(gg.get("name"), str):
        return "", ""
    size = gg.get("size")
    return gg["name"].strip(), size.strip() if isinstance(size, str) else ""


def default_model_id(resolved):
    """The API model id for what was actually loaded: its display variant's, if it has
    one of its own; for an imported GGUF that matches no variant, its own name
    (Qwen3-0.6B: qwen3-0.6b-colibri) rather than a sibling's id; else the family's."""
    family = resolved.descriptor
    config = resolved.family_config
    head = decision_head_of(resolved)
    if head:
        return head.model_id
    matched = False
    for variant in family.display_variants:
        if all(config.get(key) == value for key, value in variant.geometry):
            if variant.model_id:
                return variant.model_id
            matched = True
            break
    name, _ = _gguf_name(resolved)
    slug = re.sub(r"[^a-z0-9.]+", "-", name.lower()).strip("-.")
    if slug and family.display_variants and not matched:   # one-model families keep their id
        return slug + "-colibri"
    return family.default_model_id


def display_for(resolved):
    """(display_name, display_scale) for what was actually loaded.

    Families without variants keep their static name. With variants, the
    first whose geometry keys all match the family config wins; a config that
    matches none is named by its own model_type with an empty scale, so the
    banner prints the measured geometry instead of a sibling's parameter
    count.
    """
    family = resolved.descriptor
    config = resolved.family_config
    head = decision_head_of(resolved)
    if head:
        for geometry, scale in head.scales:
            if all(config.get(key) == value for key, value in geometry):
                return head.display_name, scale
        return head.display_name, ""
    name, size = _gguf_name(resolved)
    if not family.display_variants:   # an imported GGUF says which model it is (Inkling-Small)
        return (name, size) if name else (family.display_name, family.display_scale)
    for variant in family.display_variants:
        if all(config.get(key) == value for key, value in variant.geometry):
            return variant.display_name, variant.display_scale
    if name:   # an imported GGUF: the name its file gives
        return name, size
    return resolved.model_type, ""


def planner_geometry(resolved, context):
    if isinstance(context, bool) or not isinstance(context, int) or context < 1:
        raise ValueError("context must be a positive integer")
    if context > resolved.descriptor.limits.max_context:
        raise ValueError(f"{resolved.descriptor.id}: context {context} exceeds "
                         f"the registered maximum {resolved.descriptor.limits.max_context}")
    if resolved.descriptor.planner_geometry is None:
        raise PlannerUnsupportedError(
            f"{resolved.descriptor.display_name}: "
            f"{resolved.descriptor.planner_unsupported_reason}")
    geometry = resolved.descriptor.planner_geometry(
        resolved.family_config, context, resolved.model_dir)
    if not isinstance(geometry, PlannerGeometry) or any(
            isinstance(value, bool) or not isinstance(value, int) or value < 0
            for value in (geometry.context_state_bytes, geometry.fixed_state_bytes,
                          geometry.workspace_bytes, geometry.configured_experts)):
        raise RegistryError(f"invalid planner geometry for {resolved.descriptor.id}")
    if geometry.configured_experts < 1 and not geometry.dense:
        raise ValueError(f"{resolved.descriptor.id}: configured expert count is zero")
    return geometry


def expert_contributions(resolved, name, size, dtype=None):
    if isinstance(size, bool) or not isinstance(size, int) or size < 0:
        raise ValueError("tensor size must be a non-negative integer")
    if dtype is not None and not isinstance(dtype, str):
        raise ValueError("tensor dtype must be a string")
    contributions = resolved.descriptor.expert_inventory(
        name, size, resolved.family_config, dtype)
    for layer, expert, byte_count in contributions:
        if layer < 0 or expert < 0 or byte_count < 0:
            raise RegistryError(f"invalid expert inventory for {resolved.descriptor.id}")
    return contributions


def resident_contribution(resolved, name, size, dtype=None):
    if isinstance(size, bool) or not isinstance(size, int) or size < 0:
        raise ValueError("tensor size must be a non-negative integer")
    inventory = resolved.descriptor.resident_inventory
    if dtype is not None and not isinstance(dtype, str):
        raise ValueError("tensor dtype must be a string")
    contribution = size if inventory is None else inventory(
        name, size, resolved.family_config, dtype)
    if isinstance(contribution, bool) or not isinstance(contribution, int) or contribution < 0:
        raise RegistryError(f"invalid resident inventory for {resolved.descriptor.id}")
    return contribution


def trunk_contribution(resolved, name, size, dtype=None):
    """VRAM bytes of the engine's dense-trunk offload for one tensor (0 for
    families whose trunk stays on the CPU)."""
    if isinstance(size, bool) or not isinstance(size, int) or size < 0:
        raise ValueError("tensor size must be a non-negative integer")
    inventory = resolved.descriptor.trunk_inventory
    if inventory is None:
        return 0
    contribution = inventory(name, size, resolved.family_config, dtype)
    if isinstance(contribution, bool) or not isinstance(contribution, int) or contribution < 0:
        raise RegistryError(f"invalid trunk inventory for {resolved.descriptor.id}")
    return contribution


def fixed_resident_contribution(resolved, name, size, dtype=None):
    """Return resident bytes that do not belong to dense or cache storage.

    This pool is model-owned and independent of cache capacity. Families
    without such an allocation return zero.
    """
    if isinstance(size, bool) or not isinstance(size, int) or size < 0:
        raise ValueError("tensor size must be a non-negative integer")
    if dtype is not None and not isinstance(dtype, str):
        raise ValueError("tensor dtype must be a string")
    inventory = resolved.descriptor.fixed_resident_inventory
    contribution = 0 if inventory is None else inventory(
        name, size, resolved.family_config, dtype)
    if isinstance(contribution, bool) or not isinstance(contribution, int) or contribution < 0:
        raise RegistryError(
            f"invalid fixed resident inventory for {resolved.descriptor.id}")
    return contribution


def public_metadata(family):
    return {
        "id": family.id,
        "model_types": list(family.model_types),
        "display_name": family.display_name,
        "display_scale": family.display_scale,
        "display_variants": [
            {"geometry": dict(variant.geometry),
             "display_name": variant.display_name,
             "display_scale": variant.display_scale}
            for variant in family.display_variants],
        "engine_artifact": family.engine_artifact,
        "engine_aliases": list(family.engine_aliases),
        "engine_group": family.engine_group,
        "internal_arch": family.internal_arch,
        "build_target": family.build_target,
        "process_names": list(family.process_names),
        "default_model_id": family.default_model_id,
        "cli_adapter": family.cli_adapter,
        "gateway_adapter": family.gateway_adapter,
        "planner_id": family.planner_id,
        "supports_accelerator": family.supports_accelerator,
        "modality": family.modality,
        "tokenizer_file": family.tokenizer_file,
        "limits": {
            "default_context": family.limits.default_context,
            "max_context": family.limits.max_context,
            "default_max_output": family.limits.default_max_output,
            "interactive_max_output": family.limits.interactive_max_output,
            "max_kv_slots": family.limits.max_kv_slots,
            "implicit_cap": family.limits.implicit_cap,
            "context_env": family.limits.context_env,
        },
        "capabilities": {
            "tools": family.capabilities.tools,
            "grammar_payload": family.capabilities.grammar_payload,
            "audio_payload": family.capabilities.audio_payload,
            "thinking": family.capabilities.thinking,
            "image": family.capabilities.image,
            "decision": family.capabilities.decision,
        },
    }
