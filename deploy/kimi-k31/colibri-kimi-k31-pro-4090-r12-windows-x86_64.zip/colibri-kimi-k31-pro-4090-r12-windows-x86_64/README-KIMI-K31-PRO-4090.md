# Kimi K3.1 Pro on one RTX 4090 (192 GB RAM, two NVMe drives)

[moonshotai/Kimi-K3.1-Pro](https://huggingface.co/moonshotai/Kimi-K3.1-Pro) is Kimi K3
post-trained -- and not only re-weighted: each of its 24 gated MLA layers carries a
DeepSeek-V3.2 style **DSA lightning indexer** (`dsa_config`; 32 heads of 128, new tensors
`self_attn.indexer.*`, about 7.4 M parameters a layer), and past 2,048 positions a query
row attends only the 2,048 earlier rows its layer's indexer scores highest. Everything else
(KDA, AttnRes, LatentMoE, the MXFP4 experts, the shard layout, the tokenizer, the chat
format) is K3's. Sources: the model card and TokenSpeed's implementation,
[lightseekorg/tokenspeed#3015](https://github.com/lightseekorg/tokenspeed/pull/3015).

**This install carries the K3.1 engine**, release kimi-k31-pro-4090-r12: `kimi_k3.exe` and
`coli_cuda_k3.dll` here were built on the RTX 4090 machine and checked there on the model
itself (BUILD-INFO-K31.txt: the commit, the toolchain, the checks). Release kimi-k3-4090-r1's
`kimi_k3.exe` does not read `dsa_config`: it would run every MLA layer dense, which is K3.1's
attention up to 2,048 positions and another one past them, and `START-KIMI-K31-PRO.cmd`
refuses such a `kimi_k3.exe`. `..\build-windows.ps1` builds the pair again from a checkout
(MinGW-w64 GCC built against msvcrt, the CUDA toolkit, Visual Studio 2022's C++ tools; it
also runs the tiny models' checks and the GPU's bit-for-bit tests). What the engine does and
how it was checked: `docs/kimi_k3.md`, section "Kimi K3.1".

| | Kimi K3 (kimi-k3-4090-r1) | Kimi K3.1 Pro (this install) |
|---|---|---|
| repository | `moonshotai/Kimi-K3` | `moonshotai/Kimi-K3.1-Pro` |
| download | `tools\download_kimi_k3_4090.ps1` | `tools\download_kimi_k31_pro_4090.ps1` |
| start | `START-KIMI-K3.cmd` | `START-KIMI-K31-PRO.cmd` (`tools\start_kimi_k31_pro_4090.ps1`) |
| folders | `C:\AI\Kimi-K3`, `D:\AI\Models\Kimi-K3` | `C:\AI\Kimi-K3.1-Pro`, `D:\AI\Models\Kimi-K3.1-Pro` |
| API model | `kimi-k3` | `kimi-k3.1-pro` |

```powershell
.\tools\download_kimi_k31_pro_4090.ps1 -DryRun   # the small files, the plan, the space check
.\tools\download_kimi_k31_pro_4090.ps1           # about 1.56 TB; rerun to continue after an interruption
.\tools\download_kimi_k31_pro_4090.ps1 -Verify   # every shard's SHA-256 against the published one
.\START-KIMI-K31-PRO.cmd                          # the API on http://127.0.0.1:18080/v1, model kimi-k3.1-pro
```

K3.1 Pro gets its own folders: `k3_layout.json` now records the repository, and the
downloader refuses a folder that holds the other model (the two need about 3.1 TB side
by side; delete K3's folders first if the drives cannot hold both). `-Repo` and
`-Revision` pick another repository or pin a commit. The tokenizer is built from the
repository's `tiktoken.model` as for K3 (`tools\k3_tokenizer.py`, run by the download).

## Measured on Kimi K3.1 Pro (2026-11-10)

[docs/experiments/kimi-k31-4090-2026-11-10](https://github.com/CyberRSR/colibri/tree/main/docs/experiments/kimi-k31-4090-2026-11-10),
the launcher's settings, each run a fresh start:

| | |
|---|---:|
| the start: the engine ready (the dense matrices from `k3_dense_cache.bin`) | **7.5 s** (9.7 s in r4; the first start writes the file: 48 s; with `-NoDenseCache` 28 s every time) |
| the API answering after `START-KIMI-K31-PRO.cmd` | 11 s |
| a 35-token question, to the first token | 28-29 s (311 GB of experts read) |
| a 5,862-token prompt | 110 s (one step, at the drives' pace) |
| a 16,511-token prompt | **190 s** (one step; 205 s in release r6, 228 s in r5, 375 s in r1's steps of 8,192) |
| a follow-up of 90 tokens on a 16,600-token conversation | 28 s to the first token |
| the same request again (a regenerated reply, a retry) | **0.27 s** to the first token (27 s before) |
| a new conversation with the same system prompt (16,501 tokens of instructions) | **19.9 s** to the first token (219 s in release r2: the instructions read again) |
| a 16,592-token conversation's next turn after another conversation | **26.6 s** to the first token (about 220 s in release r3: the conversation read again) |
| its next turn after a restart of the server | **31.9 s** to the first token (read back from its file in 0.5 s) |
| a long prompt whose client gave up, sent again | resumes after the steps it finished (a 2,962-token prompt in steps of 1,024: 187 s, not 290) |
| decode | 0.85-0.91 tok/s at a short context (the machine's own drift over a day), 0.73-0.80 right after a long prompt |

The logits of the 5,862-token prompt are the same bytes at every position with this profile
-- the routed experts, the KDA and MLA layers and the index picks on the card -- as with no
GPU path at all (1,861 s on the CPU), three runs out of three and with `K3_CHECK=1`; those of
the 16,511-token prompt are the same in one step as in steps of 8,192, and under
`-RamGB 110`.

What release r2 changed since r1's K3.1 pair (all of it keeps the bytes):

- **The start.** The load ran on one core (138 s): a parallel region asked for one thread
  around the layer loop made every matrix's quantization a team of one. Now 28 s, and 9.7 s
  from the second start on: the quantized dense matrices are kept in
  `<model folder>\k3_dense_cache.bin` (33.9 GB, `K3_DENSE_CACHE`), checked against the
  checkpoint and written again when either changed. `-NoDenseCache` turns it off,
  `-DenseCache <path>` puts it elsewhere.
- **A long prompt.** A row past 2,048 positions is computed over the list of its 2,048 picks
  on the card (`k3cu_mla_sel`), where r1 computed it against every position and weighed the
  rest 0: the attention of a 16,511-token prompt 40.9 -> 9.6 s, and no longer growing with
  the square of the context. A prompt's steps are of one size and none is short (127 rows
  left after two steps of 8,192 cost 77 s on their own), and the launcher's step is 16,384
  rows: a prompt up to 18,432 tokens is one pass over the drives.
- **RAM.** The expert cache lends slots to the conversation's rows and to a large step's
  activations and gets a step's back (`K3_LEND`): the process stays under `-RamGB` at any
  length of conversation (r1 freed experts' bytes once and read them back), and decode has
  the 10 GB that r1 kept aside for a prompt step it was not running.
- **No pins from the history** (`-Pins` to have them): on this model they cost decode 8%
  (0.78 against 0.85 tok/s) and 7 s of every start, for 5.7% of a prompt's experts found
  among them.
- **The same request again** is restored from the photo of its prompt's end, which now keeps
  the logits its first token is sampled from.

What release r3 adds (2026-11-11; the bytes kept again):

- **A new conversation.** Every conversation of one client begins with the same system prompt
  -- an agent's instructions and tool declarations, 10-20 thousand tokens -- and the turns'
  photos are all past the first user message, where two conversations already differ: a new
  conversation read the instructions again, 220 s for 16.5k tokens. The state at the end of
  the leading system messages is now photographed once and kept (`K3_ROOT_PHOTO`, from
  `K3_ROOT_MIN`, 1,024, tokens; the launcher keeps five photos, `-Photos`, one of them this
  one). It is taken inside the first prompt's step, at no cost: nothing of a step carries
  from row to row but the KDA layers' state, so each KDA layer's call is made in two at the
  position and its state copied between them -- the one call's bytes (the 5,862-token prompt
  with the calls cut at row 3,000 has the CPU's logits at every position). A new conversation
  then starts after the instructions: 19.9 and 20.3 s to the first token where it took 219 s,
  the same replies. One system prompt at a time: a conversation with other instructions
  takes the caches' rows, and the first client's next conversation reads its instructions
  once more. `K3_ROOT_PHOTO=0` turns it off.

What release r4 adds (2026-11-11; the bytes kept again):

- **Several conversations.** A request of another conversation -- a second chat, an agent's
  sub-agent with instructions of its own, a client's summary request -- wrote its rows over
  the conversation the engine held, whose next turn then read every token again. Now that
  conversation is written to a file and leaves RAM, and its next turn reads it back in a few
  seconds; the files are read at the start too, so a restarted server takes its
  conversations back (`K3_SESSIONS`; the launcher keeps up to 16 in
  `<model folder>\k3_sessions`, up to 128 GB: `-Sessions`, `-SessionDir`, `-SessionDiskGB`;
  `-Sessions 0` turns it off). A conversation's files are about 1 GB (the KDA state at its
  end and the photo of its last prompt's end) plus 66 KB a token. None of it stays in RAM,
  so the expert cache is the size it was and no reply is slower for it; nothing of it runs
  while a reply is computed (the conversation is written when another one begins, after 30 s
  with no request, and when the server stops). Measured: a 16,539-token conversation, then
  another one of 2,956 tokens, then the first one's next turn: written in 1.5 s (2.07 GB),
  read back in 4.3 s, 26.6 s to its first token; after a restart its next turn 31.9 s.
- **The expert cache no longer shrinks with every new conversation.** Releases r2 and r3
  counted a dropped conversation's rows among the ones the cache lends its slots for, until
  the process restarted: after a few long conversations the cache was gigabytes smaller and
  decode slower.
- **The history's pins (`-Pins`) cannot hang a decode** at the floor the lending stops at.

What release r5 adds (2026-11-11; the bytes kept again):

- **A cancelled prompt resumes.** A prompt of several steps (16,384 tokens a step here) keeps a
  photo of the state at the end of the last step it finished. A client that gave up waiting
  -- its timeout shorter than a long prompt -- or a user who pressed stop used to leave
  nothing, and the same prompt sent again started over, so such a client never got an
  answer; now it resumes after the steps that were done.
- **A decode token's attention** past 2,048 positions: 271 -> 253 ms at 16,500 positions,
  and the indexer's pick of 2,048 positions at 131,072 positions 0.9 -> 0.08 ms a layer.
  The rest of a token is the drives'.
- **The start**: the dense cache read ahead by threads of their own, 5.6 -> 4.6 s; the engine
  ready in 7.5 s instead of 9.4.
- **A large step**: the shared experts on the card from a thread of their own, beside the
  routed experts: a 16,511-token prompt 220.7 -> 217.7 s. The card's exact kernels are the
  limit there.

What release r6 adds (2026-11-12; the bytes kept again):

- **A large step's rows beside the card's kernels.** A prompt step on the card registers its
  big host buffers with it while it runs (18 buffers, 11 GB for 16,384 rows, 0.7 s), and the
  card's calls -- the dense matrices, the router, the shared experts, the KDA layers -- move
  their rows on a copy stream of their own while their kernels run, where the driver used to
  stage every copy from pageable memory and the host waited for each. On this machine the
  copies of every stream run in one queue in the order they were queued, so a copy is queued
  only once what it needs is done; r5's shared experts held up the routed experts' copies that
  way, and no longer do. A 16,511-token prompt 228 -> 205 s; a 5,862-token prompt waits for the
  drives and is unchanged. `K3_PIN_STEP=0` turns it off (environment variable).

What release r7 adds (2026-11-12; the bytes kept again):

- **The routed experts on the card in tile kernels.** A block takes 32 rows of an expert, its
  weights decoded once into the card's shared memory, and a thread computes 4 rows x 2-4 outputs
  where it computed one lane of one output: one expert at 300 rows 1.09 -> 0.55 ms, the same bytes.
  A 16,511-token prompt 205 -> 190 s; the routed experts' part of it now waits for the bus (their
  weights going up while their outputs come down). Only `coli_cuda_k3.dll` changed;
  `K3_GPU_EXPERT_TILES=0` keeps the old kernels.

What release r8 adds (2026-11-12):

- **A tool's picture no longer stops the conversation.** Kimi Code's Computer Use tool answers
  with a window's state as text and a screenshot; the model reads text only, and the gateway
  refused the whole request with HTTP 400 ("Colibri currently supports text message content
  only."), which stopped the agent mid-task. The screenshot now becomes a line in the tool's
  result saying an image was there and is not shown, and the tool's text reaches the model. A
  picture the user sends is still refused, and the server's log now names the reason of every
  4xx it answers. Only `openai_server.py` changed.

What release r9 adds (2026-11-12):

- **Kimi K3.1 reads pictures.** The checkpoint's own vision tower (MoonViT, 0.89 GB of its last
  two shards) runs in the engine: a picture the user sends and one a tool returns (Kimi Code's
  Computer Use screenshots) reach the model, several in a conversation. A 1568 x 830 screenshot is
  1,680 prompt tokens and 0.76 s of the card (18 s on the CPU when the card has no 0.5 GB free).
  A conversation that comes back with its pictures reuses its state over them; the tower runs only
  for the new ones. On the model: a window's title, its terminal's lines, its baud rate and its
  buttons read right, from a user's message and from a tool result. `K3_VISION=0` serves text as
  r8 did; `K3_MAX_IMAGE_TOKENS` (4,096) caps a picture. In Kimi Code add `image_in` to the model's
  `capabilities` (`~/.kimi-code/config.toml`) so that your own pictures are sent too.

What release r10 adds (2026-11-12):

- **A Kimi Code session with an old screenshot goes on.** Kimi Code keeps a tool's screenshot as
  its own reference (`blobref:image/png;<sha256>`, a file of its session folder) and, after a
  restart or an undo, can send that reference instead of the picture. r9 answered it with HTTP 400
  ("local image paths are disabled on this server"), and every next request of the session too.
  The gateway now reads such a picture from `%USERPROFILE%\.kimi-code\sessions` (the launcher's
  `COLI_CLIENT_BLOB_DIRS`), only by its hash and only when the bytes are the hash's; a picture it
  cannot read in a tool result becomes a line saying so. `openai_server.py` and the launcher changed.

What release r11 adds (2026-11-17):

- **A draft model: the same replies, 9-18% sooner.** A decode step reads the dense matrices once
  whether it carries one row or several, so it can also carry the next tokens when they can be
  guessed: [Inferact/Kimi-K3.1-Pro-DSpark](https://huggingface.co/Inferact/Kimi-K3.1-Pro-DSpark), a
  draft model trained for K3.1 Pro (5 GB), guesses them from the model's own hidden rows, and each
  guess the model then picks itself costs no step of its own. Every token is still the model's own
  pick: the logits are the same bytes with the draft model and without. A recorded Kimi Code turn
  of 23,295 tokens answered with the same tool call in 103 s instead of 121; one answered by 220
  tokens of reasoning in 248 s instead of 269. It takes 2.5 GB of the card (the dense matrices
  there 18.1 GiB instead of 20), 1.9 GB of RAM and 2 s more at the start. `START-KIMI-K31-PRO.cmd`
  turns it on when the folder beside the model holds it:

  ```powershell
  $d = 'C:\AI\Kimi-K3.1-Pro-DSpark'; mkdir $d -Force | Out-Null
  $rev = 'c197a09072916cf63172df2d9d4baef0b77ed83a'   # the files this release was measured with
  foreach ($f in 'config.json', 'model.safetensors') {   # run again to continue an interrupted download
      curl.exe -L -C - -o "$d\$f" "https://huggingface.co/Inferact/Kimi-K3.1-Pro-DSpark/resolve/$rev/$f"
  }
  (Get-FileHash "$d\model.safetensors").Hash   # 83A4F35D3A68FE69275B548A0658F687B5BDDAF48F8201F999EF81B538F1FB5F
  ```

  `-NoDraft` runs without it and `-Draft <folder>` names another folder; `-DraftP` (0.98) and
  `-DraftMax` (3) are its gate: a guess is checked when the draft model gives it that probability
  or more, at most that many a step (each 0.43 GB of RAM). The launcher's banner says which. How it
  works and how it was checked: `docs/kimi_k3.md`, "Kimi K3.1: a draft model".

What release r12 adds (2026-11-17):

- **The weights whole on both drives: prompts and decode 6% sooner, the same replies.** With every
  model file in both folders (`C:\AI\Kimi-K3.1-Pro` and `D:\AI\Models\Kimi-K3.1-Pro` each holding
  all 188, 1.56 TB) a decode step reads each expert from both drives at once (60% of its bytes from
  `C:`, 40% from `D:`) and a prompt step reads each whole from the drive with less to do, 3 readers
  a drive. On the 4090 machine a 3,759-token prompt took 100.5 s instead of 107.4, a decode token
  1.14 s instead of 1.21 and its wait for reads 289 ms instead of 364; the drives together read 14.4
  GB/s instead of 13.5 during a prompt and 12.3 instead of 11.5 during decode. A recorded agent turn
  of 23,295 tokens: its reply 101.2 s instead of 103.8 (a prompt that long is the card's, 299 s
  either way). The logits are the same bytes.
- **Each start checks `C:`.** The engine copies to the model folder every model file of
  `D:\AI\Models\Kimi-K3.1-Pro` it lacks (0.2 s when nothing is missing), as long as `C:` keeps the
  conversations' files' room plus 64 GB free (`-FillKeepGB`); what does not fit is read from `D:`.
  On the layout the download tool makes, the first start copies `D:`'s parts to `C:` (559 GB, about
  5 minutes; `-NoFill` keeps the layout as it is). For every file on both drives, copy `C:`'s to `D:`
  once:

  ```powershell
  robocopy C:\AI\Kimi-K3.1-Pro D:\AI\Models\Kimi-K3.1-Pro *.safetensors /J /MT:4   # 1,002 GB, 3 minutes here
  ```

  A file is read from both drives only when both copies have the same size and header. While only
  some files have their copy (`C:` filled, `D:` not yet), every read of such a file goes whole to the
  drive with less to do and 2 readers a drive stay, so that layout reads as fast as before.
  `-NoMirror` reads each file from one drive, `-MirrorSplit` (0.6) is `C:`'s share of a decode
  step's read, and `-IoPerDrive 0` (the default) is the engine's choice of readers. How it works and
  how it was measured: `docs/kimi_k3.md`, "Kimi K3.1: the weights on both drives".

---

Everything below is the K3 install's account, measured on Kimi K3: the experts, the drives'
shares and a prompt's expert reads are the same for K3.1 Pro, and up to 2,048 positions so
is the attention (plus one 128 x 7168 matrix a row and a layer for the index keys). The index
keys take 12 KB a position beside the MLA caches' 55 KB (`-Context 131072`: 8.8 GB at the end
of a full-length conversation, a few hundred MB while it starts -- the caches grow, see
**RAM follows the conversation** below).

---

The machine of this fork's MiMo work: a Ryzen 9 7950X3D (16 cores, AVX-512), 4 x 48 GB
DDR5 at 5400 MT/s, an RTX 4090 (24 GB), and two NVMe volumes: `C:` (one drive, 1.70 TB
free) and `D:` (three NVMe drives in one RAID 0 volume, 3.21 TB free).
[moonshotai/Kimi-K3](https://huggingface.co/moonshotai/Kimi-K3) is 1.561 TB in 96
shards: 2.8T parameters, 104B active, 93 layers (69 KDA + 24 gated MLA), 896 routed
experts of which 16 a token, native MXFP4 experts (quantization-aware trained) and BF16
everything else. The engine is [`c/kimi_k3.c`](kimi_k3.md).

## What a token costs here

| | |
|---|---:|
| one routed expert (w1, w3: 3072 x 3584 e2m1 + a scale per 32; w2 the transpose) | 17.55 MB |
| a decode token's experts, none cached: 16 x 92 MoE layers | 25.8 GB |
| the rest of the model in RAM at the engine's default bits (int4 KDA/latent/shared, int8 MLA and head) | about 35 GiB |
| 17.5 MB unbuffered reads, 3 readers: `C:` alone / `D:` alone / both at once | 10.36 / 6.56 / 10.33 + 6.57 GB/s |

Both drives at once read 16.9 GB/s, so a token whose experts all come from disk needs
at least 1.53 s of reads: about 0.65 tokens a second before any expert is found in RAM.
The RAM left beside the resident weights holds roughly 100-150 GB of experts, 7-10% of
the 1.45 TB, and K3's router was trained for flat expert use (Quantile Balancing), so
the cache's hit rate stays near that share -- it turned out higher: consecutive tokens
share many experts, and the cache holds 61.5% of those a decode token asks for (below).

## Other engines that run Kimi K3, and what was taken from them

Surveyed on 2026-10-30. None holds K3 in this machine's memory: every one is bound by
reading experts from disk here, and the ones with published single-machine numbers
read fewer bytes a token by re-encoding the experts below the checkpoint's 4.25 bits.

| Engine | What it does with K3 | Reported | Taken here |
|---|---|---|---|
| [llama.cpp](https://github.com/ggml-org/llama.cpp/pull/26185) (K3 merged 2026-08-15) with [Unsloth's GGUFs](https://unsloth.ai/docs/models/kimi-k3) | the whole graph, CPU/CUDA; experts in RAM or mmapped | quants from UD-IQ1_S (594 GB) to Q8 (1.56 TB, lossless); every one larger than 192 GB, so mmapped experts page from disk; no single-GPU decode numbers published | -- |
| [Pulsar](https://dev.classmethod.jp/en/articles/dgx-spark-pulsar-ssd-expert-streaming/) (Rust + CUDA) | GGUF experts streamed from NVMe, host and VRAM caches | 0.70 tok/s, UD-IQ1_S (about 1.8 bits a weight), DGX Spark; a larger cache was slower there | the cache sizing caution (the RAM the experts take is the drives' write target too) |
| [WASTE / warp](https://github.com/sqliteai/warp) (C) | experts re-encoded to 3-bit residual VQ (982 GB), router lookahead prefetch, one aligned read an expert | 0.45-0.62 tok/s, 64 GB M5 Pro; top-16/12/8/4 experts: 0.59/0.70/0.89/1.06 tok/s | **the next layer's router applied early to read its experts ahead** (also the MiMo engine's, 77% of its experts predicted) |
| [deltafin](https://github.com/argonautlabsai/deltafin) (Rust) | experts streamed from four SSD replicas, every expert read split across them; a draft model | 1.00 tok/s, M5 Max with four SSDs (0.55 with one); "the slowest of each layer's 16 reads sets the pace" | **every layer's reads on every drive at once** -- here by cutting each layer's shard over the drives instead of full replicas, so no extra space |
| [KTransformers](https://github.com/kvcache-ai/ktransformers) | no K3 support yet; its MXFP4 MoE operator (DeepSeek-V4-Flash) computes experts held in RAM | -- | -- (1.45 TB of experts do not fit in RAM) |
| vLLM, SGLang, TokenSpeed ([recipes](https://recipes.vllm.ai/moonshotai/Kimi-K3)) | the whole model in VRAM | 8 x H200 and up | -- |

Not taken: re-encoding the experts (WASTE's 3-bit VQ, the 1-2 bit GGUFs). K3's experts
are quantization-aware trained at MXFP4, and every published re-encode is lossy against
them; `K3_TOPP` already offers the one byte-cutting lever that keeps the experts' bits,
dropping the routing's low-weight tail, as an explicit quality choice.

From this fork's MiMo engine on the same machine: per-drive reader pools with their own
unbuffered handles, demands before prefetches, unused prefetches cancelled, the experts
computed as they arrive in the order the sum always had.

## Download and placement

```powershell
.\tools\download_kimi_k31_pro_4090.ps1 -DryRun   # the small files, the plan, the space check
.\tools\download_kimi_k31_pro_4090.ps1           # 1.56 TB; rerun to continue after an interruption
.\tools\download_kimi_k31_pro_4090.ps1 -Verify   # every shard's SHA-256 against the published one
```

The profile writes `C:\AI\Kimi-K3.1-Pro` (the model folder: config, tokenizer, layer 0, the
embeddings and the head, and 61.4% of every MoE layer's experts, 1,002 GB) and
`D:\AI\Models\Kimi-K3.1-Pro` (the other 38.6%, 559 GB): the drives' weights are their
measured read speeds, 10.4 and 6.55. Each MoE layer's shard is cut between experts
([tools/k3_download.py](tools/k3_download.py)): `C:` keeps the shard's own file,
its header rewritten in place to name only the tensors it still holds, and `D:` gets
`model-000NN-of-000096.p2.safetensors` with the rest. The engine reads them as one
model with `K3_DIRS=D:\AI\Models\Kimi-K3.1-Pro`, and a step's two drives read its experts
together. `-Join` puts the published shards back (for another engine), checked
against their SHA-256. Since release r12 every file can be on both drives instead ("What release
r12 adds", above): `robocopy C:\AI\Kimi-K3.1-Pro D:\AI\Models\Kimi-K3.1-Pro *.safetensors /J /MT:4`
puts `C:`'s files on `D:`, and the launcher's start copies `D:`'s parts to `C:` (`-NoFill`: not).

## Build and run

From `c`, with MinGW-w64 GCC, the CUDA toolkit and Visual Studio's x64 C++ tools (open the
"x64 Native Tools Command Prompt for VS 2022", or call its `vcvars64.bat` first):

```powershell
.\build_cuda.bat                                   # coli_cuda.dll (CUDA_ARCH=sm_89 for the 4090)
.\build_k3_cuda.bat                                # coli_cuda_k3.dll: a prompt step on the GPU
mingw32-make kimi_k3 CUDA_DLL=1 ARCH=native VK=0   # kimi_k3.exe with the DLLs' loaders
.\tools\start_kimi_k31_pro_4090.ps1                 # the API on http://127.0.0.1:18080/v1, model kimi-k3.1-pro
```

`mingw32-make` above means a MinGW-w64 built against **msvcrt** (winlibs'
`winlibs-x86_64-posix-seh-gcc-<v>-mingw-w64msvcrt-<v>`): the card's kernels match MinGW's
`exp_f` and `tanhf` bit for bit, so an engine built against the UCRT -- MSYS2's `ucrt64` gcc --
keeps a prompt step's routed experts, its KDA and MLA layers and its index picks on the CPU,
which is minutes for a step of 8,192 rows. The engine says at startup which one it is:
`[K3-CUDA] experts: a prompt step's routed experts ... on GPU 0 beside the CPU` when the card
has them, `[K3-CUDA] experts: off (<reason>)` when it does not.
`..\build-windows.ps1` asks gcc which runtime it targets and stops on a UCRT one (`-AllowUcrt`
builds that engine on purpose); BUILD-INFO-K31.txt names the runtime of the `kimi_k3.exe`
shipped here.

Every prompt step of a served request then says where its seconds went, so a slow prompt names
its stage instead of being one number:

```
[K3] prompt 8192/18493 (412s): attention 148.6s (MLA 92.4, K3.1's index keys and picks 4.1), MoE 261.3s (router and reads issued 21.0, latent 18.4, shared 33.2, routed experts computed 152.7, waiting for reads 26.9, their inputs 5.2, their sums 3.9)
[K3]   its experts: cache hit 9.6% (7900 of 82412 asked), read ahead 4128 experts, 3906 taken by a step
```

The profile ([tools/start_kimi_k31_pro_4090.ps1](tools/start_kimi_k31_pro_4090.ps1)) reads the
model from both folders (`K3_DIRS`), two readers per drive with the next layer's
prefetch, puts up to 20 GiB of dense matrices on the GPU and releases their host copies
(`K3_CUDA_DENSE`, `K3_CUDA_RELEASE_HOST`), keeps a decode step's routed experts on the CPU
(`K3_CUDA=0`: uploading every expert a token uses would move 25.8 GB over PCIe) and puts a
prompt step's experts, its other dense matrices, its KDA layers, its MLA attention and its routers
on the GPU too, in the CPU's arithmetic to the bit (`K3_GPU_EXPERTS`, `coli_cuda_k3.dll`; a 20 GB
pool reads the next layer's experts ahead), gives the process 174 GB of RAM (the expert
cache takes what the rest leaves), a 131,072-token context the caches grow into as the
conversation does (the MLA caches: 55 KB a token, plus K3.1's 12 KB of index keys),
prompt steps of up to 16,384 tokens (`-Chunk`; a prompt's steps are of one size, up to an
eighth more in one step; a step's 1.4 MB of RAM a token past 512 is borrowed from the expert
cache while it runs), the quantized dense matrices from `k3_dense_cache.bin`
(`-NoDenseCache`, `-DenseCache <path>`) and no pins from the history (`-Pins`).
`-CpuExperts` keeps a prompt on the CPU;
`-Cpu` keeps the dense matrices on the CPU;
`-DenseGB 21.5 -ReserveGB 1` puts 35 more on the GPU (0.78 -> 0.81 tokens a second
measured on K3) and leaves about 0.6 GiB of VRAM to other programs: past what is free, Windows
moves GPU memory to RAM without an error and every call slows down.

**RAM follows the conversation.** The caches used to be allocated whole at the first request:
`-Context 131072` meant 8.8 GB of MLA caches and index keys, held from the first token of a
35-token chat to the last of a 100k-token one, and the expert cache was sized around them. Now
they grow with the conversation (on by default): the plan projects 4,096 positions
(`K3_KV_MIN`), the rest of those 8.8 GB goes to experts while the session is idle, a request
allocates its prompt's positions plus 1,024 of the answer's (`K3_KV_GEN`) and doubles as it
writes them, and each grow says what the caches hold now:

    [K3] KV: 642 of the 131072 positions this context may reach (0.04 GB, was 214)

What the caches hold past the plan is lent by the expert cache: that many slots are retired,
the coldest of every layer in turn -- their bytes freed and nothing read into them again -- and
the line says which:

    [K3][RAM] the conversation's caches hold 1.19 GB, 0.91 GB past the plan's: the expert
    cache lends 52 slots for them (52 more, 0.00 GB of experts out; 84-85 slots a layer now)

A large prompt step borrows its activations the same way and gives them back at its end:

    [K3][RAM] a step of 16511 rows borrows 22.4 GB for its activations: the expert cache lends
    1276 slots until it ends (0.0 GB of experts out; 70-71 slots a layer meanwhile)

So the process stays under `-RamGB` at any length of conversation (measured with
`-RamGB 110`: the cache down to its floor of 32 slots a layer under a 16,511-row step, the
process at 105.6 GB, the same logits), and a conversation that really runs to 131k ends
holding its 8.8 GB out of the expert cache; the hit rate then drops the way it does with a
smaller cache. `K3_KV_GROW=0` and `K3_LEND=0` return the old behaviours, and a muxed serve
(`KV_SLOTS` above 1) keeps them. What it changes is only where the RAM is: the answers are the
bytes the whole-cache engine returns -- checked on the tiny fixtures
(`tests/kimi_k3_lend_harness.py`, `K3_CHECK=1` finding every expert the engine kept where it
left it) and on the model (above).

    [K3] KV: 642 of the 131072 positions this context may reach (0.04 GB, was 214)

A grow the machine cannot pay for takes the bytes from the experts touched longest ago and says
which:

    [K3][RAM] the conversation's rows growing wants 1.05 GB with 0.4 GB free: 53 experts out
    of their slots, 0.93 GB back (0.93 of the 1.65 GB needed)

The context a request may reach is unchanged, so a conversation that really runs to 131k ends
holding its 8.8 GB and gets it out of the expert cache on the way; the hit rate then drops the
way it does with `-Context` set high. `K3_KV_GROW=0` returns the old behaviour (allocate the
whole context at the first request), and a muxed serve (`KV_SLOTS` above 1) keeps it. What it
changes is only where the RAM is: the answers are the bytes the whole-cache engine returns --
checked on the tiny K3.1 fixture through the API, a three-turn session forced to grow at every
few tokens, and again with the eviction driven hard (the coldest experts freed between the
tokens, `K3_CHECK=1` finding every expert the engine kept where it left it). The card was busy
with another model while this went in, so nothing here is measured on K3.1 Pro itself: what the
growing cache returns to the expert cache -- 8.5 GB, roughly 5 experts a layer -- and what that
is worth in tokens a second stay to be measured.

**A conversation past the context is an answer, not a restart.** One that grew longer than
the context used to take the engine down. The framed conversation is built in a buffer
before the engine looks at it, and that buffer was 65,536 tokens whatever `-Context` said:
the builder that met its end printed `chat prompt too long` and called `exit(1)`. The
gateway started the engine again -- 62 s of weights and pinned experts -- the client resent
the same conversation, and it died again: `restart 3`, `restart 4`, once a minute forever.
The buffer now takes its size from `-Context` (plus 4,096 for the XTML framing), and a
conversation longer than even that is answered the way an over-long prompt is answered
everywhere else:

    [serve] a conversation of 266240 tokens or more does not fit this 262144-token context:
            CONTEXT_EXCEEDED, and the engine keeps serving (raise -Context / K3_MAXT for a longer one)

which the API returns as a 400 the client may compact. Nothing about a request stops the
engine any more.

**Agent turns.** The profile keeps five photos of the recurrent state (`COLI_K3_CKPT=5`,
about 434 MB each): the system prompt's end (above) and four taken at every prompt's and
every reply's end. OpenAI-compatible
agents send the model's earlier replies back without their reasoning; the conversation
then differs from what the engine holds right after the previous prompt, and without a
photo the whole conversation would be computed again -- on K3 here, hours for a long
agent session. With them the next turn restores the previous prompt's photo and computes
only what follows. A prompt's rows are computed alike in any step (the GPU's kernels
compute each row alone), so the resumed turn is the bytes of the whole conversation
computed cold: tried through the API on the tiny model, the second turn restored the
first prompt's photo (150 of 288 tokens) and answered what a cold server answered.

## Measured on the real model

[docs/experiments/kimi-k3-4090-2026-10-31](experiments/kimi-k3-4090-2026-10-31/README.md):
each run a fresh start on a 35-token chat prompt, then 45 tokens greedy, with the profile's
settings; every run gave the same text.

| | the first engine (71c243f5) | 2026-10-31 (33351592) | now, the profile |
|---|---:|---:|---:|
| start: read, quantize, upload to the GPU | 161 s | 53 s | 44 s |
| the 35-token prompt | 57.0 s | 34.4 s | 32.9 s |
| decode | 0.56 tok/s | 0.79 tok/s | **0.80 tok/s** (0.81 with 4,096-token steps' RAM, 0.83 without the read-ahead pool) |
| read from the drives a decode token | 16.8 GB | 12.1 GB | 12.9 GB |
| a 2,637-token prompt (`raw/run19`, `run51`, `kda_2637_*`) | 1,401 s (f62cbd17, 512-token steps) | 549 s (the CPU, 2,048-token steps) | **106 s** (25 tok/s, one step on the GPU; C:'s reads its floor) |
| a 5,862-token prompt (`raw/big_4096_time`, `kda_5862_*`, `moe_5862_*`, `mlb_5862_*`, `mll_5862_*`, `hl_5862_*`, `tl_5862_*`) | -- | -- | **110 s** (53 tok/s, one 8,192-token step; 112 s with each thread of the tile kernels decoding its own weights, 119 s with the card's matrices in coli_cuda.dll's kernels, 122 s with the MLA layers call by call, 131-132 s with the MLA core in 64-by-64 tiles, 147-149 s before the MoE's tail went over every worker, 173 s with KDA's heads on the CPU, 254 s in two steps of 4,096) |

Every row of the last column gave the logits of the commit before (the 35-token prompt's,
and the 2,637-token prompt's at all 2,637 positions against a run with the read-ahead off)
and the same text, until the card's matrices went over to the CPU's arithmetic: since then
the logits are the CPU build's (both long prompts at every position against a run with no GPU
path at all).

Where a decode token's 1.24 s goes (the last column): attention 153 ms; the MoE 1,073 ms
-- the routing and issuing its reads 59, the latent projection 57, the shared experts 167,
the routed experts computed 497, waiting for reads 286 -- and the head 2. The routed
experts' compute reads their 25.8 GB from RAM at about 52 GB/s (16 threads read 66 GB/s at
most) while the drives write 12.1 GB into it: the cache (98 experts a layer, 11% of them)
holds 61.5% of what a token asks for, and the next layer's prediction names 57% of the
routed experts before their routing. The GPU's 404 dense matrices take 111 ms a token.

## What changed in the engine

| Change | Effect on the numbers |
|---|---|
| a pool of readers per drive (2 each), their own unbuffered handles on Windows, demands before prefetches; each expert computed as soon as its bytes are in, in the step's order | none: the logits of every configuration tested are the old loader's, byte for byte |
| the next MoE layer's experts predicted after a decode step's attention and read ahead, unused ones cancelled unread | none (a prediction only decides what is read early) |
| a step's experts summed in the order of their ids as text, the published shards' own order | none on the published layout; the cut layout gives the same bytes in any folder order |
| the largest dense matrices on the GPU (`K3_CUDA_DENSE`), host copies released | none since 2026-11-03: `coli_cuda_k3.dll` computes them in the CPU's arithmetic, so the GPU's logits are the CPU build's. Before, quant_matmul's sums in another order: on the tiny fixture's 70 positions the same argmax and max KL 4e-12, over 6,000 positions the top token at 2 of them differed (max KL 0.094) |
| the load's quantization over every worker; the RAM budget without the GPU's released host copies; OpenMP regions on omp_spin.c's spinning team | none |
| a step's experts in waves: every read issued at once on its drive, whatever arrived computed together, the sum in the old order (`K3_WAVES`) | none |
| the reads issued before the latent projection, the shared experts computed while none has arrived | none |
| the prediction from the next layer's own mix, its 12 best experts (`K3_PREFETCH_MIX`, `K3_PREFETCH_TOP`) | none (a prediction only decides what is read early) |
| the routers kept in BF16, widened in the f32 kernel's order | none: the f32 copy's bits from half the bytes |
| the load's quantization in chunks of 128 rows instead of 1,024 (`QCHUNK`): a `[7168,7168]` matrix fed 7 workers of a 28-thread team, which is what the start waited on -- the same run's `[PIN]` line reads 53.3 GB at 4.8 GB/s with one reader at a time, while the load took 44.5 s for 89 layers | none: a row is quantized alone (int8 per row, int4 per 64-column group of one row), so the chunk's size cannot change a byte of what lands in RAM. What it changes is the 44 s start above, and that is the box's number to read, not this page's: the card was serving another model while this went in |

The dense matrices on the 4090 against the CPU kernels (`tests/bench_k3_cuda_dense.c`,
random weights, the time of a whole call with its copies; "tiled" is
`coli_cuda_matmul_tiled`, which a step of two rows or more takes):

| matrix | GPU, 1 row | CPU, 1 row | GPU, 32 rows | tiled, 32 rows | CPU, 32 rows | GPU, 512 rows | tiled, 512 rows |
|---|---:|---:|---:|---:|---:|---:|---:|
| KDA q/k/v/g, 12288 x 7168 int4-g64 | 0.06 ms (0.19) | 0.90 ms | 5.6 ms | 1.5 ms | 18.7 ms | 77.8 ms | 18.7 ms |
| MLA o, 7168 x 12288 int8 | 0.11 ms (0.17) | 0.98 ms | 4.8 ms | 1.7 ms | 12.5 ms | 74.8 ms | 24.4 ms |
| shared gate/up, 6144 x 7168 int4-g64 | 0.04 ms (0.09) | 0.72 ms | 2.5 ms | 0.7 ms | 9.2 ms | 38.8 ms | 9.5 ms |
| head, 163840 x 7168 int8 | 1.2 ms (2.2) | 18.4 ms | -- | -- | -- | -- | -- |

One row runs `quant_matvec_warp` (in brackets: `quant_matmul`, before it): a warp an
output, each lane taking 8 of quant_matmul's 256 threads -- their columns of a 256-column
chunk are one 32-bit word of int4, two float4 of the input -- with their own chains of
fused adds and quant_matmul's tree over them between lanes, so its bytes are
quant_matmul's (`COLI_CUDA_QMR=0` goes back to it). With 20 GiB of them on the card a
decode token's dense work there is about 25 ms in this bench (60 before) where the CPU
streamed the same bytes from RAM in about 360 ms. The plain kernel reads a
weight once per row; the tiled one decodes it once for 8 rows and serves 8 outputs from
each input, with quant_matmul's own sums and tree, so its bytes are the plain kernel's
(`tests/test_cuda_matmul_tiled.c`: 91 shapes and row counts, and one row of 18 shapes,
K3's among them, against quant_matmul's arithmetic done on the CPU; the tiny model's GPU
logits are the same bytes in prompt steps of 1, 7 and 32 tokens). On the real model the
faster kernel took attention from 178 to 136 ms a token and the text stayed the same, but
not the token's time: the drives' reads then took the 42 ms back (run14 in the experiment
record), the decode being as fast as the experts that are not in RAM arrive. With
`coli_cuda_k3.dll` a decode row runs `k3_mv4` and `k3_mv8` instead, in the CPU's arithmetic:
0.05 ms at KDA's projections, 0.10-0.11 at MLA's gate and o_proj, 1.2 at the head, a token's
held matrices about 24 ms (`bench_k3_mv.c`; 24-29 in the kernels above).

## Not done yet

Done since: the card's own matrices in `quant_matmul_blocked` (16 outputs by 8 rows a
thread, quant_matmul's bytes: 72 -> 24 ms a 2,637-row KDA projection), the exact dense
kernel's lanes in one thread (`k3_dense_b`, the CPU's bytes: 3.3 -> 13-15 TMAC/s), steps
up to 16,384 rows (the launcher's 8,192), the GPU's calls 1,024 rows at a time, the KDA
layers whole on the card (`k3cu_kda`: a 5,862-token prompt 173.7 -> 149.2 s, the same bytes)
the MoE step's copies and tail (`k3_down` writing whole 128-byte rows into the pinned
outputs, the inputs' quantization and the weighted sums over every worker: 147.4 -> 130 s)
the MLA core in 128-by-128 tiles with exp_f in float pairs, a step in one call with its
copies under the kernels (the core 11.6 -> 4.0 s: 131.7 -> 122.7 s), the MLA layers whole
on the card (`k3cu_mla_layer`: 11.2 -> 9.0 s, 122.2 -> 121.0 s), the card's matrices in the
CPU's arithmetic (`k3_dense_b` and the int8 `k3_dense_b8` on coli_cuda.dll's copies, `k3_mv4` and
`k3_mv8` for decode: the GPU's logits the CPU build's, 119.0 -> 111.1 s, decode unchanged), and
the tile kernels' weights decoded once a block into shared memory (`k3_dense_s4`, `k3_dense_o8`:
13-15 -> 16-21 and 11-14 -> 17-23 TMAC/s, the same bytes; at 5,862 tokens the KDA layers 15.1 ->
13.7 s and the MLA layers 8.2 -> 6.7 s, the prompt 111.9 -> 109.7 s on average, the rest gone
into waiting for reads).

- **The cold prompt waits for C:.** A step of 4,096 rows or more reads nearly every expert
  once, 1.4 TB, 61.4% from C: (8.2 GiB/s while busy): C: reads 92% of the 2,637-token
  prompt, so about 100-108 s is its floor. Today's speeds would put C:'s share at 59.4%
  (about 3 s).
- **The routed experts' copies** are 90% of the MoE's expert phase: 1.3 TB in 56.5 s at
  5,862 tokens, 23 GB/s against 26 alone (the drives' DMA and the CPU share the RAM they are
  read from). The shared experts hold the main thread meanwhile (18.0 s at 5,862 tokens): on
  a helper thread they would leave it to compute CPU waves, about 3,000 experts and 2 s of
  copies less. Their call itself moves its weights (148 MB a layer) and its rows up and down
  from pageable memory on its kernels' own stream: 126 ms alone at a layer's 5,862 rows (140
  with the old tile kernels), about 196 ms in the prompt beside the routed experts' copies.
- **The MLA core's products** (`k3cu_mla`, 4.0 s at 5,862 tokens, the square of the
  context) reach about 59% of the card's FP32 peak in the scores (two instructions a
  product: rounded, then added) and 36% in the values (fused); register-level tuning of the
  128-by-128 tiles might give a few seconds more at long contexts.
- **The tile kernels' rate.** `k3_dense_s4` and `k3_dense_o8` run 16-21 and 17-23 TMAC/s, about
  half of what the card's FP32 pipes issue: the int4 kernel's operands (3 shared-memory loads of
  2 of the pipe's cycles each a 32-FMA step) keep that pipe 75% busy, and its tile is as large as
  255 registers allow beside hsum256's partial sums. In the prompt they are no longer what holds
  it: at 5,862 tokens the attention's 3 s went partly into waiting for C:'s reads (0.8 -> 3.1-5.3
  s), and pieces of 1,024 rows did not shorten the KDA layers (`kr_*`), whose pieces also go up
  and down on the kernels' own stream.
- **A rare fault in the MoE step.** One run of 2,637 tokens with every matrix the host's
  (`raw/hl_2637_none`) left the CPU's bytes from position 1,226 on. 32 runs of that
  configuration since gave them, with `K3_CHECK` (each expert's bytes checked from its read to its
  use, the output rows canaried, every layer's rows and pairs hashed) and with timing variants, and
  tests of the card's memory, the RAM and the expert kernels at the machine's clocks (the card's
  memory +1,600 MHz, the RAM 4 x 48 GB at 5,400 MT/s) found no error: open; `K3_CHECK_DUMP` and
  `ckdiff.py` locate it if it returns. The hunt found and fixed a hang in the reads: a drive that
  fell behind filled its prefetch queue with the holes that promotions leave, and the overflow's
  exit deadlocked in `k3_io_stop` (the experiment record's "The rare fault, hunted").
- **The VRAM beside the resident matrices** is 2-2.5 GiB: a program that takes more of the
  card after the start (the desktop compositor held 1.6-1.7 GB) can still push the prompt's
  buffers into RAM; `-ReserveGB 3` keeps 10 matrices off the card (decode 0.81 -> 0.80 tok/s,
  the same bytes) and leaves 1 GB more.
- **Routed experts on the GPU at decode** were tried (`raw/dec_*`): 0.70 against 0.81 tok/s,
  the card's copies taking the RAM bandwidth the CPU's experts read.
