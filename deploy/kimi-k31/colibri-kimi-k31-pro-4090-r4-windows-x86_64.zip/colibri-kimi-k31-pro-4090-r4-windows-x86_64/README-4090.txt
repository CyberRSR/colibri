colibri on one RTX 4090 + 192 GB RAM + two NVMe drives, Windows x64: Kimi K3.1 Pro and MiMo-V2.6-Pro

Unzip anywhere (e.g. C:\colibri) and start one model at a time:

  START-KIMI-K31-PRO.cmd   Kimi K3.1 Pro (tools\start_kimi_k31_pro_4090.ps1)  README-KIMI-K31-PRO-4090.md
                           weights: tools\download_kimi_k31_pro_4090.ps1 (moonshotai/Kimi-K3.1-Pro)
                           engine: K3.1's kimi_k3.exe and coli_cuda_k3.dll are here (BUILD-INFO-K31.txt);
                           the first start writes <model folder>\k3_dense_cache.bin (33.9 GB), the next start in 10 s;
                           a new conversation starts after its system prompt, kept from the first one (20 s, not 220, for 16.5k tokens);
                           a conversation another one interrupted, or a restart left behind, comes back from its file
                           in <model folder>\k3_sessions (27-32 s to its next reply, not 220; -Sessions 0: off)
  START-MIMO.cmd           MiMo-V2.6-Pro-MOPD (tools\start_mimo_cuda_4090.ps1)  README-MIMO-4090.md
  START-MIMO-HERETIC.cmd   MiMo-V2.6-Pro-MOPD-heretic (the same launcher, -Model heretic)

API: http://127.0.0.1:18080/v1 (OpenAI and Anthropic). Arguments after the .cmd go to its launcher
(model folders, threads, context): see each README. The other engines and `coli` are colibri's.

Needs: an AVX-512 CPU (built for Zen 4), an RTX 40xx with a CUDA 12/13 driver (the runtime is in
the DLLs), Python 3.10+ for the API server, about 192 GB of RAM for these profiles.

BUILD-INFO.txt: the commit and SHA-256 of every engine binary.
